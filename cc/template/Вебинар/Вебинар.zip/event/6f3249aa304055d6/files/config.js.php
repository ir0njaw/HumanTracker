

var Config = {};

Config.api = {
	url: window.location.protocol + '//api.webinar.ru',
	url_old: window.location.protocol + '//api.comdi.com',
	crossDomainUrl: window.location.protocol + '//my.webinar.ru/api0/crossdomain.php',
	//crossDomainUrl: window.location.protocol + '//comdi_2.dev/api0/crossdomain.php',
	crossDomainMethod: 'POST',
	getRequestUrl: function(url) {
		return Config.api.url + url;
	},
	answerStatus: function(status, data) {
		//var error = JSON.parse(data);
		switch(status) {
			case 409:
				alert('Такой пользоватеть уже существует.');
			break;
		}
	}
};

Config.comet = {
	url: window.location.protocol + '//comet.mysql',
	pingInterval: 60*1000
}


Config.msg = {"host":"nulled.webinar.ru","port":80,"vhost":"webinar","username":"nulled","password":"nulled"}
Config.hosts = {
	api: 'api.webinar.ru',
	agreement: 'webinar.ru/legal/service-agreement',
	host: 'mysql',
	storage: 'storage.webinar.ru',
	mainSite: 'webinar.ru',
	payment: 'payment.webinar.ru',
	octopus: 'octopus.webinar.ru',
	help: 'support.webinar.ru',
	halo: 'halo.comdi.com',
	deimos: 'deimos.comdi.com',
	ab: 'ab.webinar.ru',
	wowzaRecord: ["records-m9.webinar.ru","live-sd.webinar.ru","live-m9.webinar.ru"],
	wowzaView: ["live-m9.webinar.ru","live-sd.webinar.ru"]}

Config.platform = 'my.webinar.ru';

if(!String.prototype.trim) {
String.prototype.trim = function () {
return this.replace(/^\s+|\s+$/g,'');
};
}
