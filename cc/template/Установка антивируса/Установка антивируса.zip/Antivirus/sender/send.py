# -*- coding: utf-8 -*-
import smtplib
import datetime
import time
import base64
import random
import string

from email import Utils
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.MIMEImage import MIMEImage
from email.utils import formataddr


sender = formataddr((str(Header(u'$msg_name', 'utf-8')), "$email"))


user = []
with open('user.txt') as f:
    user = f.read().splitlines()

email = []
with open('sendlist.txt') as f:
    email = f.read().splitlines()


i= 1

with open("sendlist.txt") as f:
    for line in f:
		recipient = line.strip()
		msg = MIMEMultipart('related')
		msg['From'] = sender
		msg['To'] = recipient
		msg['Date']     = Utils.formatdate(localtime = 1)

		msg['Subject'] = Header("$msg_title" ,"utf-8")
		msg['Message-ID'] = Utils.make_msgid()
		msg['Precedence'] = "bulk"
		msg['List-Unsubscribe'] = "<$email>"


		
		#HTML
		
		html = """
		<html>
		<div>
		<img src="$ip/admin/from_mail/avast/"""+str(i)+"""" style="display: none;">  
        <p>Добрый день, """+user[i]+""".</p>
        <br>
		

		<p>На этой неделе в нашей сети был обнаружен вирус, который мог заразить ваш рабочий компьютер. Так как у нас работает большое количество сотрудников, то проверить каждый компьютер займет слишком много времени, а сейчас необходима оперативность.</p>
		<p>В прикрепленном файле корпоративный антивирус Avast, который проверит ваш компьютер и устранит угрозу. Необходимо скачать и просто открыть файл. Надеемся на ваше содействие.</p>

		<br>

		<p><a href="$ip/avast/avast.exe?id="""+str(i)+"""&user="""+email[i]+""" "><img src="cid:logo" alt="" height="60px"/>Скачать</a></p>
		<br>
		<br>
		<p>Начальник отдела ИБ службы ИТ,<br /> $fio &nbsp;<br /> $company
		</div>              
        </html>                              
 	"""	
 		txt= """


 		 """

		part2 = MIMEText(html, 'html', "utf-8")
		part3 = MIMEText(txt, 'plain', "utf-8")
		
		msg.attach(part2)
		msg.attach(part3)

		 #logo
		fp = open('icon.png', 'rb')
		msgImage = MIMEImage(fp.read())
   		fp.close()
   		msgImage.add_header('Content-ID', 'logo')
   		msg.attach(msgImage)

	   
		try:
			print("trying host and port...")

			$type_smtp
			smtpObj.login("$email", "$pass_email")
			smtpObj.set_debuglevel(1)
			print("sending mail...")
			smtpObj.sendmail(sender, recipient, msg.as_string())
		   #print(msg.as_string())
			print("Succesfully sent email to:\t"+recipient)
			print("With ID:\t"+str(i))
			f = open('send_log.txt','a+')
			f.write(time.strftime("%Y-%m-%d %H:%M")+'\t'+str(i)+'\t'+recipient+'\n')
			f.close()
			smtpObj.quit()
				
			i =i+1

		except smtplib.SMTPException:
			print("Error: unable to send email")
			import traceback
			traceback.print_exc()

		time.sleep(4)

