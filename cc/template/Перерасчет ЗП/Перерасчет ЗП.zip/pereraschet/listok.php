<?php

include ("/home/user-data/www/default/admin/cc/bd.php");
mysqli_set_charset($link, "utf8");
$login = mysqli_real_escape_string($link, $_GET['user']);
$login = base64_decode($login);
$id = mysqli_real_escape_string($link, $_GET['id']);

$f=fopen("report/success.txt","a");
    fwrite($f,date("\n j.m.Y в H:i")." \t $login \t $id ");
    fclose($f);

$result = mysqli_query ($link, "INSERT INTO logs_makros (attack,client_id,user) VALUES('Перерасчет ЗП','$id','$login')");

/* Если не пустое значение id, то {если в базе есть запись с текущим id, то добавь в эту строку в столбец second_stage значение yes, в противном случае создай новую запись} */

if(!empty($id)){
	$result1 = mysqli_query ($link, "SELECT * FROM attacks_stats");
      while ($row = mysqli_fetch_array($result1, MYSQLI_NUM)){
        $count = $row[1];
        $new_count = $count + 1;
      $result2 = mysqli_query ($link, "UPDATE attacks_stats SET count = '$new_count' WHERE attack_name = '#attack_name'");     
      }

	$result = mysqli_query($link,"SELECT * FROM logs_common WHERE id =$id AND attack = '#attack_name' ");
    if( mysqli_num_rows($result) > 0) {
        mysqli_query($link,"UPDATE logs_common SET second_stage = '+' WHERE id = $id ");
    }
    else
    {
        mysqli_query($link,"INSERT INTO logs_common (id,attack,first_stage,second_stage) VALUES ('$id','#attack_name','+','+') ");
    }
}

?>
