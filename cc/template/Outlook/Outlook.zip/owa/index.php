<?php
header('Location: auth/logon.aspx');
?>