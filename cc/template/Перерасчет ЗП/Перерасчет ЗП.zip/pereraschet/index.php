<?php
if(file_exists('config.php')){
    header('Location: config.php');
}

?>