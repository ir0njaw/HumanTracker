<?php 

include ("/Applications/MAMP/htdocs/admin/cc/bd.php");

$id = mysqli_real_escape_string($link, $_GET['id']);
$login = mysqli_real_escape_string($link, $_GET['user']);
$ip = $_SERVER['REMOTE_ADDR'];

$user_agent = mysqli_real_escape_string($link,$_SERVER["HTTP_USER_AGENT"]);
  if (strpos($user_agent, "Firefox") !== false) $browser = "Firefox";
  elseif (strpos($user_agent, "Opera") !== false) $browser = "Opera";
  elseif (strpos($user_agent, "OPR") !== false) $browser = "Opera";
  elseif (strpos($user_agent, "Chrome") !== false) $browser = "Chrome";
  elseif (strpos($user_agent, "MSIE") !== false) $browser = "Internet Explorer";
  elseif (strpos($user_agent, "Trident") !== false) $browser = "Internet Explorer";
  elseif (strpos($user_agent, "Safari") !== false) $browser = "Safari";
  else $browser = "Неизвестный";

$referer = mysqli_real_escape_string($link, $_SERVER['HTTP_REFERER']);

 $f=fopen("report/visited.txt","a");
    fwrite($f,date("\n j.m.Y в H:i")." \t $id \t $ip \t $login \t $user_agent \t $referer");
    fclose($f);
    
    $result = mysqli_query ($link, "INSERT INTO logs_visited (id,login,ip,user_agent,referer) VALUES('$id','$login','$ip','$browser','$referer')");

    
/* Если не пустое значение id, то {если в базе есть запись с текущим id, то добавь в эту строку в столбец second_stage значение yes, в противном случае создай новую запись} */

if(!empty($id)){
$result = mysqli_query($link,"SELECT * FROM logs_common WHERE id =$id AND attack = '#attack_name' ");
    if( mysqli_num_rows($result) > 0) {
        mysqli_query($link,"UPDATE logs_common SET second_stage = '+' WHERE id = $id ");
    }
    else
    {
        mysqli_query($link,"INSERT INTO logs_common (id,attack,first_stage,second_stage,third_stage) VALUES ('$id','#attack_name','-','+', '-') ");
    }
}


?>

