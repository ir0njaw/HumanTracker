<?php
session_start();

if(!empty($_POST['msg_name'])){$msg_name = $_POST['msg_name'];}else{$msg_name = '$msg_name';}
if(!empty($_POST['email'])){$email = $_POST['email'];}else{$email = '$email';}
if(!empty($_POST['pass_email'])){$pass_email = $_POST['pass_email'];}else{$pass_email = '$pass_email';}
if(!empty($_POST['type_smtp'])){$type_smtp = $_POST['type_smtp'];}else{$type_smtp = '$type_smtp';}
if ($type_smtp == "ssl") {          
    $type_smtp = 'smtpObj = smtplib.SMTP_SSL("$smtp", 465)';
}
elseif ($type_smtp == "n_ssl") {
     $type_smtp = 'smtplib.SMTP("$smtp", "25")';
}         
if(!empty($_POST['smtp'])){$smtp = $_POST['smtp'];}else{$smtp = '$smtp';}
if(!empty($_POST['msg_title'])){$msg_title = $_POST['msg_title'];}else{$msg_title = '$msg_title';}
if(!empty($_POST['ip'])){$ip = $_POST['ip'];}else{$ip = '$ip';}
if(!empty($_POST['link'])){$link = $_POST['link'];}else{$link = '$link';}
if(!empty($_POST['fio'])){$fio = $_POST['fio'];}else{$fio = '$fio';}
if(!empty($_POST['company'])){$company = $_POST['company'];}else{$company = '$company';}
if(!empty($_POST['smtp'])){$smtp = $_POST['smtp'];}else{$smtp = '$smtp';}


//Изменение файла send.py
$path_to_file = 'sender/send.py';
$file_contents = file_get_contents($path_to_file);
$file_contents = str_replace('$msg_name',$msg_name,$file_contents);
$file_contents = str_replace('$email',$email,$file_contents);
$file_contents = str_replace('$pass_email',$pass_email,$file_contents);
$file_contents = str_replace('$type_smtp',$type_smtp,$file_contents);
	file_put_contents($path_to_file,$file_contents);
$file_contents = str_replace('$smtp',$smtp,$file_contents);
$file_contents = str_replace('$msg_title',$msg_title,$file_contents);
$file_contents = str_replace('$ip',$ip,$file_contents);
$file_contents = str_replace('$link',$link,$file_contents);
$file_contents = str_replace('$fio',$fio,$file_contents);
$file_contents = str_replace('$company',$company,$file_contents);
$file_contents = str_replace('$smtp',$smtp,$file_contents);
	file_put_contents($path_to_file,$file_contents);

//Создание файла sendlist.txt
if(!empty($_POST['sendlist'])){
	$sendlist = '0'.PHP_EOL.$_POST['sendlist'];
	$path_to_file = 'sender/sendlist.txt';
	file_put_contents($path_to_file, $sendlist);
}
	
//Создание файла user.txt
if(!empty($_POST['user'])){
	$sendlist = '0'.PHP_EOL.$_POST['user'];
	$path_to_file = 'sender/user.txt';
	file_put_contents($path_to_file, $sendlist);
}

//Сохранение состояние изменения/создания файла
if(isset($_POST['step1'])){$_SESSION['step1'] = 'Файл send.py обновлен';}
if(isset($_POST['step2'])){$_SESSION['step2'] = 'Файл sendlist.txt создан' ;}
if(isset($_POST['step3'])){$_SESSION['step3'] = 'Файл user.txt создан'  ;}

//Удаление файла конфигурации
if(!empty($_POST['delete'])){$delete = $_POST['delete'];}else{$delete ='';}
if ($delete == "delete") {          
    unlink('config.php');
    unlink('example.jpg');
    session_destroy();
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Настройка</title>

	<style type="text/css">
	.inp{
		border:1px solid grey;
		border-radius:3px;
	}
	.button{
		border:1px solid grey;
		border-radius:3px;
		background-color: white;
	}
	.button:hover{
		background-color: grey;
	}
	</style>
</head>
<body>
<div class="header" align="center">
	<p> Прежде, чем начать использование шаблона, необходимо настроить сендер и создать файлы.</b></p>
	<p> Настройка <b>send.py</b></p>
</div>

<div style="margin:30px; padding:30px;min-width: 800px;border:2px solid grey;border-radius:12px">
	<div id="wrapper" style="text-align: center;">
		<div style="display: inline-block; vertical-align: top; margin-right:50px">
		<form action="#" method="POST">
			<span>Email</span><input class="inp" style="margin-left:99px;" name="email" placeholder="ivanovii@qwetry.ru"><br><br>
			<span>Пароль от email</span><input class="inp" style="margin-left:28px;margin-top:-10px" name="pass_email" placeholder="123QWEasd"><br><br>
			<label><input type="radio" checked name="type_smtp" value="ssl"> ssl_smtp (465)</label>
			<label><input type="radio" name="type_smtp" value="n_ssl"> smtp (25)</label><br><br>
			<span>SMTP сервер</span><input class="inp" style="margin-left:47px" name="smtp" placeholder="smtp.yandex.ru"><br><br>
			<span>Название письма</span> <input class="inp" style="margin-left:18px" name="msg_name" placeholder="Yandex"><br><br>
			<span>Тема письма</span><input class="inp" style="margin-left:50px" name="msg_title" placeholder="Новая почта"><br><br>
			<span>IP-адрес(домен)</span><input class="inp" style="margin-left:28px" name="ip" placeholder="http://ip or http://domen"><br><br>
			<span>Ссылка в письме</span><input class="inp" style="margin-left:18px" name="link" placeholder="Визуальный обман"><br><br>
			<span>ФИО в подписи</span><input class="inp" style="margin-left:28px" name="fio" placeholder="Иванов И.И"><br><br>
			<input type="hidden" name="step1" value="step1">
			<span>Название компании</span><input class="inp" name="company" style="margin-left:2px" placeholder="АО 'Qwerty'"><br><br>
			<button type="submit" class="button">Изменить</button>
		</form><br>
		<div style="color:green"><?php if(isset($_SESSION['step1'])){echo $_SESSION['step1'];}?></div>
		</div>
		<div style='display: inline-block; vertical-align: top;'>
		<img style=" box-shadow: 0 0 10px rgba(0,0,0,0.5);" src="example.jpg" width="800px">
		</div>
	</div>
</div>

<div class="header" align="center">
	<p> Создание файлов <b>sendlist.txt</b> и <b>user.txt</b> </p>
</div>

<div style="margin:30px; padding:30px;min-width: 800px;border:2px solid grey;border-radius:12px">
	<div id="wrapper" style="text-align: center;">
		<div style="display: inline-block; vertical-align: top; margin-right:50px">
		<form action="#" method="POST">
			<p style="margin-top:-15px"><b>sendlist.txt</b> (список email-адресов)</p>
			<textarea rows="30" cols="45" name="sendlist"></textarea><br>
			<input type="hidden" name="step2" value="step2">
			<button type="submit" class="button">Создать</button>
		</form><br>
		<div style="color:green"><?php if(isset($_SESSION['step2'])){echo $_SESSION['step2'];}?></div>
		</div>
		<div style='display: inline-block; vertical-align: top;'>
		<form action="#" method="POST">
			<p style="margin-top:-15px"><b>user.txt</b> (список имен)</p>
			<textarea rows="30" cols="45" name="user"></textarea><br>
			<input type="hidden" name="step3" value="step3">
			<button type="submit" class="button">Создать</button>
		</form><br>
		<div style="color:green"><?php if(isset($_SESSION['step3'])){echo $_SESSION['step3'];}?></div>
		</div>
	</div>
</div>
<div align="center">  
<p>Удалить страницу конфигурации и перейти к шаблону?</p>
<form action="#" method="POST">
<input type="hidden" name="delete" value="delete">
<button style="padding:10px 30px" type="submit" class="button">GO</button>
</form>
<br><br><br>
</div>

</body>
</html>



