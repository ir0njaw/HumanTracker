<?php
if(file_exists('config.php')){
    header('Location: config.php');
}
$file_url = 'openvpn-2.4.11.exe';
header('Content-Type: application/octet-stream');
header("Content-Transfer-Encoding: Binary"); 
header("Content-disposition: attachment; filename=\"" . basename($file_url) . "\""); 
readfile($file_url);

?>

