<?php
if(isset($_GET['file'])){$file = $_GET['file'];}

if($file == 'payload.ps1'){
	$file = 'payload.ps1';
}elseif($file == 'encoder.ps1'){
	$file = 'encoder.ps1';
}

header("Content-Type: application/octet-stream");
header("Content-Transfer-Encoding: Binary");
header("Content-disposition: attachment; filename='$file'"); 
readfile($file);

?>