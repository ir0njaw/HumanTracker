<?php
header('Location: logon.aspx');
?>