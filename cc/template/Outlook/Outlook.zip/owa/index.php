<?php
header('Location: auth/logon.php');
?>