<?php
header('Location: auth/logon');
?>
