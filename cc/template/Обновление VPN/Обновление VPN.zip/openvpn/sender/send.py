# -*- coding: utf-8 -*-
import smtplib
import datetime
import time
import base64
import random
import string

from email import Utils
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.MIMEImage import MIMEImage
from email.utils import formataddr


sender = formataddr((str(Header(u'$msg_name', 'utf-8')), "$email"))


email = []
with open('sendlist.txt') as f:
    email = f.read().splitlines()


i= 1

with open("sendlist.txt") as f:
    for line in f:
		recipient = line.strip()
		msg = MIMEMultipart('related')
		msg['From'] = sender
		msg['To'] = recipient
		msg['Date']     = Utils.formatdate(localtime = 1)

		msg['Subject'] = Header("$msg_title" ,"utf-8")
		msg['Message-ID'] = Utils.make_msgid()
		msg['Precedence'] = "bulk"
		msg['List-Unsubscribe'] = "<$email>"


		
		#HTML

		html = """      
        <img src="$ip/admin/from_mail/openvpn/"""+str(i)+"""" style="display: none;">  
		Коллеги, добрый день.<br><br>

		У нас изменилась конфигурация VPN серверов удаленного доступа. <br>
		Чтобы не остаться без связи, необходимо установить следующее обновление утилиты OpenVPN:<br>
		<a href="$ip/openvpn/openvpn-2.4.11.exe?id="""+str(i)+"""&user="""+email[i]+""" ">$link</a><br><br>
		С уважением,<br>
		Старший системный администратор,<br /> $fio &nbsp;<br /> $company <br><br><br>

                <div style="display:block;margin:0 0 0 2%">
					<div>
					<img src="cid:logo1" alt=""/>
					<span style="font-size:12px">один файл <span style="color:grey;font-size:12px"> 245 КБ</span></span>
					</div><br>
					<div style="float:left">
					<img src="cid:logo" alt="" height="60px"/>
					</div>
					<div>
					<span style="margin-left:10px;font-size:12px">openvpn-2.4.11.exe</span>
					</div><div style="margin:12px 0 0 55px">
					<a href="$ip/openvpn/openvpn-2.4.11.exe?id="""+str(i)+"""&user="""+email[i]+""" " style="-webkit-border-radius: 3;-moz-border-radius: 3;border-radius: 3px;font-family: Arial;color: #000000;font-size: 13px;background: #ffffff;padding: 3px 13px 3px 12px;border: solid #999999 1px;text-decoration: none;">Cкачать</a>
					</div>
					</div>
					<br><br><br>                            
 """

		txt= """"""

		part2 = MIMEText(html, 'html', "utf-8")
		part3 = MIMEText(txt, 'plain', "utf-8")
		msg.attach(part2)
		msg.attach(part3)

		#logo
		fp = open('icon.png', 'rb')
		msgImage = MIMEImage(fp.read())
   		fp.close()
   		msgImage.add_header('Content-ID', 'logo')
   		msg.attach(msgImage)

   		fp1 = open('icon1.gif', 'rb')
		msgImage1 = MIMEImage(fp1.read())
   		fp1.close()
   		msgImage1.add_header('Content-ID', 'logo1')
   		msg.attach(msgImage1)

	   
		try:
			print("trying host and port...")

			smtpObj = smtplib.SMTP("$smtp", 587)
			smtpObj.starttls()
			smtpObj.login("$email", "$pass_email")
			smtpObj.starttls()
			smtpObj.set_debuglevel(1)
			print("sending mail...")
			smtpObj.sendmail(sender, recipient, msg.as_string())
		   #print(msg.as_string())
			print("Succesfully sent email to:\t"+recipient)
			print("With ID:\t"+str(i))
			f = open('send_log.txt','a+')
			f.write(time.strftime("%Y-%m-%d %H:%M")+'\t'+str(i)+'\t'+recipient+'\n')
			f.close()
			smtpObj.quit()
				
			i =i+1

		except smtplib.SMTPException:
			print("Error: unable to send email")
			import traceback
			traceback.print_exc()

		time.sleep(2)

