/** tracking v1.0.0*/
var trackingConfig = {
    ApiKey: "bTOVPcCqCA7tmyCtLTwsrNC1kKm5JVAQMlX3CCVm",
    serviceUrl: "https://webtracking-v01.bpmonline.com/Tracking"
};
var tracking = (function () {
    /**
    * Cookie name.
    */
    var sessionCookieName = "bpmSessionId";

    /**
    * Set cookie.
    * @param {String} The key (cookie name) of the cookie.
    * @param {String} The value of a specified cookie.
    */
    function setCookie(name, value) {
        var expires;
        var date = new Date();
        var expiresCookieDays = 180;
        date.setTime(date.getTime() + (expiresCookieDays * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
        document.cookie = name + "=" + value + expires + "; path=/";
    }

    /**
    * Returns new GUID.
    * @return {String} GUID.
    */
    function newGuid() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
    }

    /**
    * Returns the value of cookie with the specified key.
    * @param {String} key The key (cookie name) of the cookie.
    * @return {String}  The value of a specified cookie.
    */
    function getCookie(key) {
        if (!key) {
            return "";
        }
        var cookie = document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" +
            key + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1") || "";
        if (!cookie) {
            cookie = newGuid();
            setCookie(key, cookie);
        }
        return cookie;
    }

    /**
    * Returns an object that will sent to the server.
    * @param {Object} config Data specified on the tracking.
    * @return {Object} Data to be sent to the server.
    */
    function getTrackingData(config) {
        data = {};
        data.ApiKey = config.ApiKey;
        data.TimeZoneOffset = (new Date()).getTimezoneOffset();
        data.SessionId = getCookie(sessionCookieName);
        data.Url = window.location.href;
        return data;
    }

    return {
        /**
         * Creates a tracking event on the data specified.
         * Performs an asynchronous HTTP (Ajax) request to the server.
         * @param {Object} config Data specified.
         * @param {Object} object event.
         * @param {String} identifier of the type of event.
         */
        postSiteEvent: function(config, eventObject, eventTypeId) {
            if (!eventTypeId) {
                return;
            }
            var trackingData = getTrackingData(config, eventTypeId);
            trackingData.EventTypeId = eventTypeId;
            /*var eventParameters = {};
            for (key in eventObject) {
                if (eventObject.hasOwnProperty(key)) {
                    var value = eventObject[key] && eventObject[key].toString();
                    eventParameters[key] = value;
                }
            }
            trackingData.EventObject = eventParameters;*/
            jQuery.ajax({
                url: config.serviceUrl,
                type: "POST",
                data: JSON.stringify(trackingData),
                contentType: "application/json; charset=UTF-8",
                async: true,
                crossDomain: true,
                error: function(jsxhr, status, error) {
                    if (jQuery.isFunction(config.onError)) {
                        config.onError(jsxhr, status, error);
                    }
                },
                success: function(response) {
                },
                complete: function(response) {
                    if (jQuery.isFunction(config.onComplete)) {
                        config.onComplete(response);
                    }
                }
            });
        }
    }
})();

/**
* The generated part of the code for handling events site.
*/
function EventTrackingElement() {
    /*SCRIPT START*/
/*START-49d9adf0-2645-44ad-b08d-d14a748286d6*/
if (window.location.href === 'http://webinar.ru/functions/dlya-soveshchaniy') {tracking.postSiteEvent(trackingConfig, null, '49d9adf0-2645-44ad-b08d-d14a748286d6');}
/*END-49d9adf0-2645-44ad-b08d-d14a748286d6*/
/*START-015f81bd-eb48-4c15-ac6e-b075b278526d*/
if (window.location.href === 'http://webinar.ru/functions/dlya-obucheniya/') {tracking.postSiteEvent(trackingConfig, null, '015f81bd-eb48-4c15-ac6e-b075b278526d');}
/*END-015f81bd-eb48-4c15-ac6e-b075b278526d*/
/*START-45913fdf-ab55-4c1c-88cb-c9ae2000f2bf*/
if (window.location.href === 'http://webinar.ru/functions/dlya-marketinga') {tracking.postSiteEvent(trackingConfig, null, '45913fdf-ab55-4c1c-88cb-c9ae2000f2bf');}
/*END-45913fdf-ab55-4c1c-88cb-c9ae2000f2bf*/
/*START-6e99cdd2-ff56-47a7-ba5f-6fca97f11856*/
if (window.location.href === 'http://webinar.ru/functions/') {tracking.postSiteEvent(trackingConfig, null, '6e99cdd2-ff56-47a7-ba5f-6fca97f11856');}
/*END-6e99cdd2-ff56-47a7-ba5f-6fca97f11856*/
/*START-82b27010-d53c-411c-a8e2-dee1cb9e4e2b*/
if (window.location.href === 'http://webinar.ru/clients') {tracking.postSiteEvent(trackingConfig, null, '82b27010-d53c-411c-a8e2-dee1cb9e4e2b');}
/*END-82b27010-d53c-411c-a8e2-dee1cb9e4e2b*/
/*START-8c5734fa-69da-4d4f-8e9d-22d36ddc1cbc*/
if (window.location.href === 'http://webinar.ru/study') {tracking.postSiteEvent(trackingConfig, null, '8c5734fa-69da-4d4f-8e9d-22d36ddc1cbc');}
/*END-8c5734fa-69da-4d4f-8e9d-22d36ddc1cbc*/
/*START-cee461c0-a887-4b7f-a6aa-51994bc5eda4*/
jQuery('.btn top-contacts-btn js-show-right-panel').click(function(eventObject) {tracking.postSiteEvent(trackingConfig, eventObject, 'cee461c0-a887-4b7f-a6aa-51994bc5eda4');});
/*END-cee461c0-a887-4b7f-a6aa-51994bc5eda4*/
/*START-46f226bd-8d0e-4241-ba21-12e9b998f623*/
if (window.location.href === 'http://webinar.ru/contacts/') {tracking.postSiteEvent(trackingConfig, null, '46f226bd-8d0e-4241-ba21-12e9b998f623');}
/*END-46f226bd-8d0e-4241-ba21-12e9b998f623*/
/*START-87039da8-4818-4cf9-adb3-3c621768dd8f*/
if (window.location.href === 'http://webinar.ru/metodichka') {tracking.postSiteEvent(trackingConfig, null, '87039da8-4818-4cf9-adb3-3c621768dd8f');}
/*END-87039da8-4818-4cf9-adb3-3c621768dd8f*/
/*START-ae772b3d-0756-4f36-8392-1fbe32d1f82a*/
if (window.location.href === 'http://webinar.ru/livedemo') {tracking.postSiteEvent(trackingConfig, null, 'ae772b3d-0756-4f36-8392-1fbe32d1f82a');}
/*END-ae772b3d-0756-4f36-8392-1fbe32d1f82a*/
/*START-4bd34f31-ccd6-4a5e-accc-2f9e7dbcb6b3*/
if (window.location.href === 'http://webinar.ru/academy') {tracking.postSiteEvent(trackingConfig, null, '4bd34f31-ccd6-4a5e-accc-2f9e7dbcb6b3');}
/*END-4bd34f31-ccd6-4a5e-accc-2f9e7dbcb6b3*/
/*START-2767e8de-0fbb-4c79-81df-50c075e14001*/
if (window.location.href === 'http://webinar.ru/blog') {tracking.postSiteEvent(trackingConfig, null, '2767e8de-0fbb-4c79-81df-50c075e14001');}
/*END-2767e8de-0fbb-4c79-81df-50c075e14001*/
/*START-fe7ffd24-e880-4402-8f90-09e93f0b0876*/
if (window.location.href === 'http://webinar.ru/tariffs/') {tracking.postSiteEvent(trackingConfig, null, 'fe7ffd24-e880-4402-8f90-09e93f0b0876');}
/*END-fe7ffd24-e880-4402-8f90-09e93f0b0876*/
    /*SCRIPT END*/
}
if (window.addEventListener) {
    window.addEventListener('load', EventTrackingElement, true);
} else if (element.attachEvent) {
    window.attachEvent('onload', EventTrackingElement);
}
