<?php
header('Location: event/6f3249aa304055d6/');
?>