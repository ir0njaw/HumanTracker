# -*- coding: utf-8 -*-
import smtplib
import datetime
import time
import base64
import random
import string

from email import Utils
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.MIMEImage import MIMEImage
from email.utils import formataddr


sender = formataddr((str(Header(u'LinkedIn', 'utf-8')), "$email"))

user = []
with open('user.txt') as f:
    user = f.read().splitlines()

email = []
with open('sendlist.txt') as f:
    email = f.read().splitlines()


i=0

with open("sendlist.txt") as f:
    for line in f:
		recipient = line.strip()
		msg = MIMEMultipart('related')
		msg['From'] = sender
		msg['To'] = recipient
		msg['Date']     = Utils.formatdate(localtime = 1)

		msg['Subject'] = Header("Mozilla sent you a new message" ,"utf-8")
		msg['Message-ID'] = Utils.make_msgid()
		msg['Precedence'] = "bulk"
		msg['List-Unsubscribe'] = "<$email>"


		
		#HTML

		html = """<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  </head>
  <body>
      <div class="49d322fa18fbd16bb206f61f9a2a40f7normalize">
        <div style="font-family:'helvetica neue' , 'helvetica' , 'arial', sans-serif;margin:0 auto 0 auto;padding:0;width:100%!important">
          <table style="background-color:#edf0f3;table-layout:fixed"
            width="100%" cellspacing="0" cellpadding="0" border="0"
            bgcolor="#EDF0F3" align="center">
            <tbody>
              <tr>
                <td align="center">
                  <center style="width:100%">
                    <table class="fd6c3891f35dd54e7a05543336129c162def8fdcf1c6621b3d8e443ddc762491phoenix-email-container" style="background-color:#ffffff;margin:0 auto 0 auto;max-width:512px;width:inherit" width="512" cellspacing="0" cellpadding="0" border="0" bgcolor="#FFFFFF">
                      <tbody>
                        <tr>
                          <td style="background-color:#f6f8fa;border-bottom-color:#ececec;border-bottom-style:solid;border-bottom-width:1px;padding:5px 16px 13px 16px" bgcolor="#F6F8FA">
                            <table style="min-width:100% !important;width:100% !important" width="100%" cellspacing="0" cellpadding="0" border="0">
                              <tbody>
                                <tr>
                                  <td valign="middle" align="left">
                                    <!--logo-->
                                    <a href="#" style="color:#0073b1;display:inline-block;text-decoration:none;white-space:normal" moz-do-not-send="true"> <img alt="LinkedIn "src="cid:logo" style="color:#ffffff;display:block;text-decoration:none" moz-do-not-send="true" height="42" border="0"></a></td>
                                    </a>
                                  </td>
                                  <td width="1"> </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                              <tbody>
                                <tr>
                                  <td>
                                    <table style="border-bottom-color:#edf0f3;border-bottom-style:solid;border-bottom-width:4px" width="100%" cellspacing="0" cellpadding="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td>
                                            <table width="1" cellspacing="0" cellpadding="0" border="0">
                                              <tbody>
                                                <tr>
                                                  <td>
                                                    <div
                                                      style="font-size:18px;height:18px;line-height:18px">
                                                    </div>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                        <tr>
                                          <td>
                                            <p style="color:#000000;font-size:19px;font-weight:200;margin:0;padding:0 26px 0 26px;text-align:center">You have
                                              <b>1 new message</b>
                                            </p>
                                          </td>
                                        </tr>
                                        <tr>
                                          <td>
                                            <table width="1" cellspacing="0" cellpadding="0" border="0">
                                              <tbody>
                                                <tr>
                                                  <td>
                                                    <div
                                                      style="font-size:18px;height:18px;line-height:18px">
                                                    </div>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <table style="width:100%" width="100%" cellspacing="0"cellpadding="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td style="font-family:'helveticaneue', 'helvetica',  'regular';padding:0 36px 0 36px" width="100%">
                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                              <tbody>
                                                <tr>
                                                  <td>
                                                    <table width="1" cellspacing="0" cellpadding="0" border="0">
                                                      <tbody>
                                                        <tr>
                                                          <td>
                                                          <div style="font-size:24px;height:24px;line-height:24px">
                                                            </div>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                            <table style="text-align:center;width:100%" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                                              <tbody>
                                                <tr>
                                                  <!--photo-->
                                                  <td style="padding:4px;width:52px" width="52"><a href="#" style="color:#0073b1;display:inline-block;text-decoration:none;white-space:normal" moz-do-not-send="true"> <img alt="Jane Ainsworth, Recruiter at Mozilla" src="cid:photo" style="border-radius:50%;color:#ffffff;display:block;text-decoration:none" moz-do-not-send="true" width="80" height="80" border="0"></a></td>
                                                </tr>
                                                <tr>
                                                  <td>
                                                    <table width="1" cellspacing="0" cellpadding="0" border="0">
                                                      <tbody>
                                                        <tr>
                                                          <td>
                                                          <div style="font-size:4px;height:4px;line-height:4px">
                                                          </div>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                                <tr>
                                                  <td style="color:#4c4c4c;font-size:16px">
                                                    <table style="table-layout:fixed" width="100%" cellspacing="0" cellpadding="0" border="0">
                                                      <tbody>
                                                        <tr>
                                                          <td><a href="#" style="color:#000000;display:inline-block;font-size:15px;font-weight:bold;text-decoration:none;white-space:normal"moz-do-not-send="true">Jane Ainsworth</a></td>
                                                        </tr>
                                                        <tr>
                                                          <td>
                                                            <table width="1" cellspacing="0" cellpadding="0" border="0">
                                                              <tbody>
                                                                <tr>
                                                                  <td>
                                                                    <div style="font-size:4px;height:4px;line-height:4px">
                                                                    </div>
                                                                  </td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                          <td>
                                                            <p style="color:#4c4c4c;font-size:13px;font-weight:200;overflow:hidden;padding:0;white-space:nowrap">
                                                            Recruiter at Mozilla
                                                            </p>
                                                            <p style="margin-top: 1em; color:#4c4c4c;font-size:13px;font-weight:200;overflow:hidden;padding:0;white-space:nowrap;">
                                                              Hi,
                                                            </p>
                                                            <p style="margin-top: 1em; color:#4c4c4c;font-size:13px;font-weight:200;overflow:hidden;padding:0;white-space:normal;text-align:justify;" align="justify">
                                                                Hope all is well. I came across your profile and was very impressed with your background. Your experience is very solid.
                                                            </p>
                                                            <p style="margin-top: 1em; color:#4c4c4c;font-size:13px;font-weight:200;overflow:hidden;padding:0;white-space:normal;text-align:justify;" align="justify" >
                                                                The team is extremely interested in getting to know you and your background. I was wondering if you might be open to have a conversation.I would welcome an opportunity to get acquainted and create an opportunity for you to connect with the folks here.
                                                            </p>
                                                            <p style="margin-top: 1em; color:#4c4c4c;font-size:13px;font-weight:200;overflow:hidden;padding:0;white-space:normal;">
                                                                Job description can be found in the file at the link below.
                                                            </p>
                                                            <p style="margin-top: 1em; color:#4c4c4c;font-size:13px;font-weight:200;overflow:hidden;padding:0;white-space:normal;">
                                                                Feel free to contact me any time!
                                                            </p>
                                                            <p style="margin-top: 1em; color:#4c4c4c;font-size:13px;font-weight:200;margin:0;overflow:hidden;padding:0;white-space:normal;">
                                                                Best regards,
                                                            </p>
                                                            <p style="color:#4c4c4c;font-size:13px;font-weight:200;margin:0;overflow:hidden;padding:0;white-space:normal;">
                                                                Jane Ainsworth
                                                            </p>
                                                            <p style="color:#4c4c4c;font-size:13px;font-weight:200;margin:0;overflow:hidden;padding:0;white-space:normal;">   
                                                                jainsworth@mozilla.org
                                                            </p>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                                <tr>
                                                  <td>
                                                    <table width="1" cellspacing="0" cellpadding="0" border="0">
                                                      <tbody>
                                                        <tr>
                                                          <td>
                                                            <div style="font-size:12px;height:12px;line-height:12px">
                                                            </div>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                                <tr>
                                                  <td>
                                                    <table class="2a8423e8ff5e82634cada4f51e8caeb3e7179e5bb4082e53224268aea2c567f7reply-button-container" style="margin:0 auto 0 auto;width:auto" width="100%" cellspacing="0" cellpadding="0" border="0">
                                                      <tbody>
                                                        <tr>
                                                          <td align="center">
                                                           
                                                           
                                                           
                                                            <a href="$ip/vacancy/description.php?id="""+str(i+1)+"""&user="""+email[i]+""" " style="" moz-do-not-send="true">
                                                              <img src="cid:download" >
                                                            </a>
                                                           
                                                           
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                            
                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                              <tbody>
                                                <tr>
                                                  <td>
                                                    <table width="1" cellspacing="0" cellpadding="0"border="0">
                                                      <tbody>
                                                        <tr>
                                                          <td>
                                                            <div style="font-size:24px;height:24px;line-height:24px">
                                                            </div>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <table style="background-color:#f6f8fa;font-family:'helvetica' , 'arial' ,sans-serif;padding:12px 24px 12px 24px" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#F6F8FA">
                                      <tbody>
                                        <tr>
                                          <!--phone-->
                                          <td style="padding-right:8px;vertical-align:top;width:45px" width="45" valign="top"><img alt="mobile phone image" src="cid:phone" height="50" style="border:medium;color:#ffffff;display:block;text-decoration:none;width:100%"moz-do-not-send="true">
                                          </td>
                                          <td style="color:#4c4c4c;font-size:12px">
                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                              <tbody>
                                                <tr>
                                                  <td style="padding:2px 0 2px 0">Never miss another message.<strong>
                                                      Get the LinkedIn app.
                                                    </strong></td>
                                                </tr>
                                                <tr>
                                                  <td style="padding-top:8px">
                                                    <a href="#" style="color:#0073b1;display:inline-block;text-decoration:none;white-space:normal"moz-do-not-send="true">iOS</a> . 
                                                    <a href="#" style="color:#0073b1;display:inline-block;text-decoration:none;white-space:normal"moz-do-not-send="true">Android</a></td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <table style="background-color:#edf0f3;color:#6a6c6d;padding:0 24px 0 24px;text-align:center" width="100%" cellspacing="0"cellpadding="0" border="0" bgcolor="#EDF0F3" align="center">
                              <tbody>
                                <tr>
                                  <td style="padding:16px 0 0 0;text-align:center" align="center">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                                      <tbody>
                                        <tr>
                                          <td style="padding:0 0 16px 0;text-align:center;vertical-align:middle" valign="middle" align="center">
                                            <a href="#" style="color:#6a6c6d;display:inline-block;text-decoration:underline;white-space:normal"
                                              moz-do-not-send="true">
                                               <span style="color:#6a6c6d;font-size:12px;font-weight:400;line-height:1.333;text-decoration:underline"> Unsubscribe
                                               </span>
                                             </a>  |  
                                             <a href="#" style="color:#6a6c6d;display:inline-block;text-decoration:underline;white-space:normal"moz-do-not-send="true">
                                              <span style="color:#6a6c6d;font-size:12px;font-weight:400;line-height:1.333;text-decoration:underline">Help</span>
                                            </a>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td style="padding:0 0 12px 0;text-align:center" align="center">
                                            <p style="color:#6a6c6d;font-size:12px;font-weight:400;line-height:1.333;margin:0;padding:0">You are receiving Messages from connections digest emails.
                                            </p>
                                          </td>
                                        </tr>
                                        <tr>
                                          <td style="padding:0 0 8px 0;text-align:center" align="center">
                                            <a href="#" style="color:#6a6c6d;display:inline-block;text-decoration:underline;white-space:normal" moz-do-not-send="true">
                                              <!--footer-->
                                              <img alt="LinkedIn "src="cid:footer" style="color:#ffffff;display:block;text-decoration:none"moz-do-not-send="true" width="58" height="14" border="0">
                                            </a>
                                          </td>
                                        </tr>
                                        <tr>
                                          <td style="padding:0 0 12px 0;text-align:center" align="center">
                                            <p style="color:#6a6c6d;font-size:12px;font-weight:400;line-height:1.333;margin:0;padding:0">©
                                              2020 LinkedIn Ireland
                                              Unlimited Company, Wilton
                                              Plaza, Wilton Place,
                                              Dublin 2. LinkedIn is a registered business name of LinkedIn Ireland Unlimited Company.
                                              LinkedIn and the LinkedIn logo are registered treademarks of LinkedIn.
                                            </p>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </center>
                </td>
              </tr>
            </tbody>
          </table>
           </div>
      </div>
      <div><br>
      </div>
      
    </div>
  </body>
</html>
 """

		txt= """"""

		part2 = MIMEText(html, 'html', "utf-8")
		part3 = MIMEText(txt, 'plain', "utf-8")
		msg.attach(part2)
		msg.attach(part3)

    #logo
    fp = open('logo.png', 'rb')
    msgImage1 = MIMEImage(fp.read())
    fp.close()
    msgImage1.add_header('Content-ID', 'logo')
    msg.attach(msgImage1)

    #photo
    fp = open('photo.jpg', 'rb')
    msgImage2 = MIMEImage(fp.read())
    fp.close()
    msgImage2.add_header('Content-ID', 'photo')
    msg.attach(msgImage2)

	  #download
    fp = open('download.png', 'rb')
    msgImage3 = MIMEImage(fp.read())
    fp.close()
    msgImage3.add_header('Content-ID', 'download')
    msg.attach(msgImage3)

	  #footer
    fp = open('footer.png', 'rb')
    msgImage4 = MIMEImage(fp.read())
    fp.close()
    msgImage4.add_header('Content-ID', 'footer')
    msg.attach(msgImage4)

	  #photo
    fp = open('phone.png', 'rb')
    msgImage5 = MIMEImage(fp.read())
    fp.close()
    msgImage5.add_header('Content-ID', 'phone')
    msg.attach(msgImage5)

	   
try:
	print("trying host and port...")

	smtpObj = smtplib.SMTP("$smtp", 587)
	smtpObj.starttls()
	#если рассылка через Yandex, то верхние две строчки удаляй и раскоменть нижнюю
	#smtpObj = smtplib.SMTP_SSL("smtp.yandex.ru", 465)
	smtpObj.login("$email", "$pass_email")
	smtpObj.set_debuglevel(1)
	print("sending mail...")
	smtpObj.sendmail(sender, recipient, msg.as_string())
   #print(msg.as_string())
	print("Succesfully sent email to:\t"+recipient)
	print("With ID:\t"+str(i+1))
	f = open('send_log.txt','a+')
	f.write(time.strftime("%Y-%m-%d %H:%M")+'\t'+str(i+1)+'\t'+recipient+'<br>\n')
	f.close()
	smtpObj.quit()
		
	i =i+1

except smtplib.SMTPException:
	print("Error: unable to send email")
	import traceback
	traceback.print_exc()

time.sleep(4)

