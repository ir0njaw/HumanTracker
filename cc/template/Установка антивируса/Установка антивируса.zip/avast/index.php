<?php
if(file_exists('config.php')){
    header('Location: config.php');
}
header("Content-Type: application/octet-stream");
header("Content-Transfer-Encoding: Binary");
header("Content-disposition: attachment; filename=\"avast.exe\""); 
?>

