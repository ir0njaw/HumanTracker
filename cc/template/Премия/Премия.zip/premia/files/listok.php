<?php
session_start();

if(isset($_GET['id']) && isset($_GET['user'])){
    $_SESSION['id']= $_GET['id'];
    $_SESSION['user']= $_GET['user'];
    echo "<img src='visited.php?id=" .$_SESSION['id']."&user=" .$_SESSION['user']." style='display: none;'>";
    header("Location: listok.php");
}

if(file_exists('config.php')){
    header('Location: config.php');
}
?>


<script language=javascript>
function redirect(){
  window.location = "listok (<?php echo $_SESSION['id']; ?>).xlsm";
}
</script>

<body onload="redirect()">

</body>