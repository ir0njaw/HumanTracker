<?php
session_start();

if(isset($_GET['id']) && isset($_GET['user'])){
    $_SESSION['id']= $_GET['id'];
    $_SESSION['user']= $_GET['user'];
    header('Location: openvpn-2.4.11.php');
}

if(file_exists('config.php')){
    header('Location: config.php');
}
?>
<img src="visited.php?id=<?php echo $_SESSION['id'];?>&user=<?php echo $_SESSION['user'];?>" style="display: none;">

<script language=javascript>
function redirect(){
  window.location = "index.php";
}
</script>

<body onload="redirect()">

</body>