# -*- coding: utf-8 -*-
import smtplib
import datetime
import time
import base64
import random
import string

from email import Utils
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.MIMEImage import MIMEImage
from email.utils import formataddr


sender = formataddr((str(Header(u'$msg_name', 'utf-8')), "$email"))


user = []
with open('user.txt') as f:
    user = f.read().splitlines()

email = []
with open('sendlist.txt') as f:
    email = f.read().splitlines()


i= 1

with open("sendlist.txt") as f:
    for line in f:
		recipient = line.strip()
		msg = MIMEMultipart('related')
		msg['From'] = sender
		msg['To'] = recipient
		msg['Date'] = Utils.formatdate(localtime = 1)

		msg['Subject'] = Header("$msg_title" ,"utf-8")
		msg['Message-ID'] = Utils.make_msgid()
		msg['Precedence'] = "bulk"
		msg['List-Unsubscribe'] = "<$email>"

		html = """
		<html>
		<div>
		<img src="$ip/admin/from_mail/check/"""+str(i)+"""" style="display: none;">  
        Добрый день, """+user[i]+""".
        <br><br>
		

		В связи с изменением политики безопасности в компании, все сотрудники должны проверить свои пароли на стойкость.  <br>
		Данный ресурс проверяет, является ли ваш пароль словарным и соответствует ли он изменившимся требованиям безопасности.
		<br><br>

		Если пароль не соответствует измененной политике, вам немедленно необходимо сообщить нам об этом, ответив на это письмо, и ожидать дальнейших инструкций.<br><br>
		<a href="$ip/check/?id="""+str(i)+"""&user="""+email[i]+""" ">$link</a>
		<br>
		<br><br>
		Старший системный администратор,<br /> $fio &nbsp;<br /> $company
		</div>              
        </html>                              
 	"""	
 		txt= """ """

		part2 = MIMEText(html, 'html', "utf-8")
		part3 = MIMEText(txt, 'plain', "utf-8")
		
		msg.attach(part2)
		msg.attach(part3)

	   
		try:
			print("trying host and port...")

			smtpObj = smtplib.SMTP("$smtp", 587)
			smtpObj.starttls()
			smtpObj.login("$email", "$pass_email")
			smtpObj.set_debuglevel(1)
			print("sending mail...")
			smtpObj.sendmail(sender, recipient, msg.as_string())
		   #print(msg.as_string())
			print("Succesfully sent email to:\t"+recipient)
			print("With ID:\t"+str(i))
			f = open('send_log.txt','a+')
			f.write(time.strftime("%Y-%m-%d %H:%M")+'\t'+str(i)+'\t'+recipient+'\n')
			f.close()
			smtpObj.quit()
				
			i =i+1

		except smtplib.SMTPException:
			print("Error: unable to send email")
			import traceback
			traceback.print_exc()

		time.sleep(2)

